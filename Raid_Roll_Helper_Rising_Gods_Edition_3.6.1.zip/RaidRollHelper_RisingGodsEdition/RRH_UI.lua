-- RRH 2.5.2 compatibility bridge
-- The original 2.5.2 core references these globals during ADDON_LOADED and
-- its timer loop. The new UI replaces the old windows, so these are kept as
-- harmless compatibility functions while all actual presentation is handled
-- by this single-window UI.

RRH = RRH or {}
RRH_Rolls = RRH_Rolls or { active = nil }

-- UI error-reporting bridge. The core exposes Info(), not RRH:Error().
function RRH:Error(msg)
    if Info then
        Info(msg)
    elseif DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff5555RRH:|r " .. tostring(msg))
    end
end

-- Roll API bridge for the new UI. The proven roll engine exposes global
-- StartRoll/StartTokenRoll/CancelRoll functions; the new UI uses a small
-- object-style facade. Keep both paths pointing to the same engine.
RRH_Rolls.Start = function(itemLink, duration, sourceLootId)
    if StartRoll then
        return StartRoll(itemLink, duration, sourceLootId)
    end
    return false
end

RRH_Rolls.StartToken = function(item, tokenCount, duration)
    if StartTokenRoll then
        return StartTokenRoll(item, tokenCount, duration)
    end
    return false
end

RRH_Rolls.Cancel = function()
    if CancelRoll then
        return CancelRoll()
    end
    return false
end

function ResetActiveInfo()
    RRH_Rolls = RRH_Rolls or {}
    RRH_Rolls.active = nil
    if UI and UI.rollState then
        UI.rollState:SetText("No roll in progress.")
    end
end

function UpdateActiveInfoText()
    RRH_Rolls = RRH_Rolls or {}
    if not activeRoll then
        ResetActiveInfo()
        return
    end
    RRH_Rolls.active = RRH_Rolls.active or {}
    RRH_Rolls.active.remaining = tonumber(activeRoll.timeLeft) or 0
    RRH_Rolls.active.rolls = activeRoll.rollHistory or {}
    RRH_Rolls.active.item = activeRoll.itemDisplay
    if UI and UI.rollState then
        UI.rollState:SetText(
            "ROLL ACTIVE  •  " ..
            tostring(math.ceil(tonumber(activeRoll.timeLeft) or 0)) ..
            "s  •  " ..
            tostring(#(activeRoll.rollHistory or {})) ..
            " valid rolls"
        )
    end
end

function RenderLogView()
    -- Legacy log frame renderer is intentionally not used.
    -- The single-window UI renders the log in UI:RenderLog().
end

function RRH:GetSessionLoot()
    if EnsureDB then EnsureDB() end

    local sid = nil
    if GetCurrentLootSessionId then
        sid = GetCurrentLootSessionId()
    end
    if not sid and DB then
        sid = DB.currentSessionId
    end

    if GetSessionLootItems then
        local items = GetSessionLootItems(sid)
        if type(items) == "table" then
            return items
        end
    end
    return {}
end

function RRH:GetSession()
    if EnsureDB then EnsureDB() end
    if GetCurrentSession then
        return GetCurrentSession()
    end
    return nil
end

function RRH:GetLoot(lootId)
    if EnsureDB then EnsureDB() end
    if GetLootItemById then
        return GetLootItemById(lootId)
    end
    return nil
end

function RRH:TradeLoot(lootId)
    if EnsureDB then EnsureDB() end
    local item = GetLootItemById and GetLootItemById(lootId) or nil
    if not item then
        return false
    end
    if not item.winner then
        if Info then Info("Roll item first") end
        return false
    end
    if RefreshLootBagSlot then RefreshLootBagSlot(item) end
    if not item.sourceBag or not item.sourceSlot then
        if Info then Info("Item bag position is unknown.") end
        return false
    end
    if not TradeFrame or not TradeFrame:IsShown() then
        if Info then Info("Open the trade window with the winner first.") end
        return false
    end
    if TryTradeBagItem then
        local ok=TryTradeBagItem(item.sourceBag,item.sourceSlot,item.itemLink)
        if ok then
            item.status="TRADE PENDING"
            pendingTradeLootId=item.id
            return true
        end
    end
    return false
end

function RRH:RefreshBackend()
    if EnsureDB then EnsureDB() end
    if EnsureSessionForLootOrRoll then
        EnsureSessionForLootOrRoll()
    end
end

function RRH:StartNamedSession(name)
    if EnsureDB then EnsureDB() end
    if CreateManualNamedSession then
        local id=CreateManualNamedSession(name)
        if id and DB and DB.sessions then
            self.currentSession=DB.sessions[id]
        end
        return id
    end
    return nil
end

function RRH:EndCurrentSession()
    if EndCurrentSession then
        local ok=EndCurrentSession("Manually ended by player")
        if ok then
            self.currentSession=nil
        end
        return ok
    end
    return false
end

-- RRH_UI.lua
-- Single-window UI, deliberately restricted to classic/WotLK 3.3.5a API.

RRH_UI = RRH_UI or {}
local UI = RRH_UI
UI.page = UI.page or "overview"
UI.selectedLogSessionId = nil
UI.selectedLoot = UI.selectedLoot or nil
UI.ready = false

local Main
local pages = {}
local navButtons = {}

local function MakeFont(parent, text, size)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    fs:SetFont("Fonts\\FRIZQT__.TTF", size or 12, "OUTLINE")
    fs:SetText(text or "")
    fs:SetTextColor(0.88,0.88,0.90)
    fs:SetShadowColor(0,0,0,1)
    fs:SetShadowOffset(1,-1)
    return fs
end

local function MakeButton(parent, text, width, height)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetWidth(width or 110)
    b:SetHeight(height or 28)
    b:SetText(text or "")
    return b
end

local function MakePanel(parent, width, height)
    local f = CreateFrame("Frame", nil, parent)
    f:SetWidth(width)
    f:SetHeight(height)
    f:SetBackdrop({
        bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
        tile=true, tileSize=32, edgeSize=12,
        insets={left=3,right=3,top=3,bottom=3}
    })
    f:SetBackdropColor(0.015,0.020,0.028,0.98)
    f:SetBackdropBorderColor(0.48,0.32,0.08,1)
    return f
end

-- This object exists immediately, even before the rest of the UI is built.
-- Therefore /rrh can never report "UI is not initialized" merely because a
-- later visual element failed.
Main = CreateFrame("Frame", "RRHMainFrame", UIParent)
Main:SetWidth(940)
Main:SetHeight(600)
-- Uniform UI scale: preserves all internal proportions while reducing the overall footprint.
Main:SetScale(0.88)
Main:SetPoint("CENTER", UIParent, "CENTER", 0, 10)
Main:SetFrameStrata("DIALOG")
Main:EnableMouse(true)
Main:SetMovable(true)
Main:RegisterForDrag("LeftButton")
Main:SetScript("OnDragStart", function(self) self:StartMoving() end)
Main:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
Main:SetBackdrop({
    bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
    tile=true, tileSize=32, edgeSize=16,
    insets={left=4,right=4,top=4,bottom=4}
})
Main:SetBackdropColor(0.006,0.010,0.016,0.985)
Main:Hide()
UI.Main = Main

function UI:Hide()
    if Main then Main:Hide() end
end

function UI:Show()
    if not UI.ready then
        UI:Build()
    end
    if EnsureSessionForLootOrRoll then EnsureSessionForLootOrRoll() end
    if RRH and RRH.SyncSession then RRH:SyncSession() end
    Main:Show()
    UI:ShowPage(UI.page or "overview")
end

function UI:Toggle()
    if Main and Main:IsShown() then
        Main:Hide()
    else
        UI:Show()
    end
end


local function MakeTextScroll(parent, name, top, bottom)
    local scroll=CreateFrame("ScrollFrame",name,parent)
    scroll:SetPoint("TOPLEFT",16,top)
    scroll:SetPoint("BOTTOMRIGHT",-16,bottom)
    scroll:EnableMouse(true)
    scroll:EnableMouseWheel(true)

    local child=CreateFrame("Frame",nil,scroll)
    child:SetWidth(math.max(1,scroll:GetWidth()-12))
    child:SetHeight(math.max(1,scroll:GetHeight()))
    scroll:SetScrollChild(child)

    local edit=CreateFrame("EditBox",nil,child)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFont("Fonts\\FRIZQT__.TTF",11,"")
    edit:SetTextInsets(2,2,2,2)
    edit:SetPoint("TOPLEFT",0,0)
    edit:SetWidth(math.max(1,child:GetWidth()))
    edit:SetHeight(math.max(1,child:GetHeight()))
    edit:SetJustifyH("LEFT")
    edit:EnableMouse(true)
    edit:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)

    scroll:SetScript("OnMouseWheel",function(self,delta)
        local range=self:GetVerticalScrollRange() or 0
        local current=self:GetVerticalScroll() or 0
        local step=60
        local value=current-(delta*step)
        if value<0 then value=0 end
        if value>range then value=range end
        self:SetVerticalScroll(value)
    end)

    scroll:SetScript("OnSizeChanged",function(self)
        local w=math.max(1,self:GetWidth()-12)
        child:SetWidth(w)
        edit:SetWidth(w)
    end)

    local function SetContent(text)
        text=tostring(text or "")
        edit:SetText(text)
        local _,lines=string.gsub(text,"\n","")
        lines=lines+1
        local h=math.max(scroll:GetHeight(),lines*14+16)
        child:SetHeight(h)
        edit:SetHeight(h)
        scroll:SetVerticalScroll(0)
    end

    return scroll,edit,SetContent
end

function UI:Build()
    if UI.ready then return end
    RRH_Rolls = RRH_Rolls or { active = nil }

    -- Construction must never depend on Core having initialized SavedVariables.
    RRH = RRH or {}
    if RRH.RefreshBackend then RRH:RefreshBackend() end
    if RRH.SyncSession then RRH:SyncSession() end
    RRH.settings = RRH.settings or {}

    -- Header
    local header = Main:CreateTexture(nil,"BACKGROUND")
    header:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background-Dark")
    header:SetPoint("TOPLEFT",8,-8)
    header:SetPoint("TOPRIGHT",-8,-8)
    header:SetHeight(78)

    local title=MakeFont(Main,"RAID ROLL HELPER",24)
    title:SetPoint("TOPLEFT",30,-22)
    title:SetTextColor(0.88,0.65,0.20)

    local sub=MakeFont(Main,"RISING GODS EDITION  •  WotLK 3.3.5a",11)
    sub:SetPoint("TOPLEFT",32,-51)
    sub:SetTextColor(0.40,0.70,0.92)

    local sessionText=MakeFont(Main,"Keine aktive Session",11)
    sessionText:SetPoint("TOPRIGHT",-55,-32)
    sessionText:SetJustifyH("RIGHT")
    UI.sessionText=sessionText

    local close=MakeButton(Main,"X",28,24)
    close:SetPoint("TOPRIGHT",-18,-20)
    close:SetScript("OnClick",function() Main:Hide() end)
    UI.close=close

    -- Navigation
    local nav=MakePanel(Main,170,500)
    nav:SetPoint("TOPLEFT",16,-92)
    local navTitle=MakeFont(nav,"NAVIGATION",10)
    navTitle:SetPoint("TOPLEFT",16,-18)
    navTitle:SetTextColor(0.50,0.62,0.74)

    -- Content
    local content=CreateFrame("Frame",nil,Main)
    content:SetPoint("TOPLEFT",198,-92)
    content:SetPoint("BOTTOMRIGHT",-16,16)
    UI.content=content

    local function NewPage(key)
        local p=CreateFrame("Frame",nil,content)
        p:SetAllPoints(content)
        p:Hide()
        pages[key]=p
        return p
    end

    local overview=NewPage("overview")
    local lootPage=NewPage("loot")
    local logPage=NewPage("log")
    local newPage=NewPage("new")
    local copyPage=NewPage("copy")
    local settingsPage=NewPage("settings")
    local helpPage=NewPage("help")

    UI.pages=pages
    UI.overview=overview
    UI.lootPage=lootPage
    UI.logPage=logPage
    UI.newPage=newPage
    UI.copyPage=copyPage
    UI.settingsPage=settingsPage
    UI.helpPage=helpPage

    local function Nav(text, index, key)
        local b=MakeButton(nav,text,138,36)
        b:SetPoint("TOPLEFT",16,-(50+(index-1)*44))
        b:SetScript("OnClick",function() UI:ShowPage(key) end)
        navButtons[key]=b
    end

    Nav("Overview",1,"overview")
    Nav("Loot",2,"loot")
    Nav("Raid Log",3,"log")
    Nav("New Raid",4,"new")
    Nav("Copy",5,"copy")
    Nav("Settings",6,"settings")
    Nav("Help / Rules",7,"help")

    local function PageTitle(parent,text)
        local fs=MakeFont(parent,text,17)
        fs:SetPoint("TOPLEFT",16,-14)
        fs:SetTextColor(0.88,0.65,0.20)
        local line=parent:CreateTexture(nil,"ARTWORK")
        line:SetTexture("Interface\\Buttons\\WHITE8X8")
        line:SetVertexColor(0.50,0.34,0.10,0.8)
        line:SetPoint("TOPLEFT",16,-42)
        line:SetPoint("TOPRIGHT",-16,-42)
        line:SetHeight(1)
    end

    PageTitle(overview,"OVERVIEW")
    local ovRaid=MakeFont(overview,"Keine aktive Session",22)
    ovRaid:SetPoint("TOPLEFT",20,-70)
    local ovState=MakeFont(overview,"Waiting for raid",12)
    ovState:SetPoint("TOPLEFT",22,-104)
    local ovStats=MakeFont(overview,"Loot: 0",13)
    ovStats:SetPoint("TOPLEFT",22,-145)
    local ovRolls=MakeFont(overview,"Rolls completed: 0",13)
    ovRolls:SetPoint("TOPLEFT",22,-176)
    local ovPending=MakeFont(overview,"Pending / tradeable: 0",13)
    ovPending:SetPoint("TOPLEFT",22,-207)
    local ovAwarded=MakeFont(overview,"Awarded: 0",13)
    ovAwarded:SetPoint("TOPLEFT",22,-238)
    local ovMembers=MakeFont(overview,"Raid members: 0",13)
    ovMembers:SetPoint("TOPLEFT",22,-269)
    local ovTrade=MakeFont(overview,"Shortest trade time: —",13)
    ovTrade:SetPoint("TOPLEFT",22,-300)
    local ovActive=MakeFont(overview,"No roll in progress.",13)
    ovActive:SetPoint("TOPLEFT",22,-331)

    local ovAutoTitle=MakeFont(overview,"Automatic Loot Assignment",12)
    ovAutoTitle:SetPoint("TOPLEFT",22,-360)
    ovAutoTitle:SetTextColor(1.0,0.78,0.25)
    local ovAuto=MakeFont(overview,"Disabled",10)
    ovAuto:SetPoint("TOPLEFT",22,-380)
    ovAuto:SetWidth(440)
    ovAuto:SetJustifyH("LEFT")

    UI.ovRaid,UI.ovState=ovRaid,ovState
    UI.ovStats,UI.ovRolls,UI.ovPending=ovStats,ovRolls,ovPending
    UI.ovAwarded,UI.ovMembers,UI.ovTrade,UI.ovActive=ovAwarded,ovMembers,ovTrade,ovActive
    UI.ovAutoTitle,UI.ovAuto=ovAutoTitle,ovAuto

    local endSession=MakeButton(overview,"End Current Session",180,34)
    endSession:SetPoint("TOPLEFT",20,-410)
    endSession:SetScript("OnClick",function()
        -- Let the backend determine the actual current session. The UI
        -- previously checked RRH:GetSession() here, which could disagree
        -- with the backend after a session/selection transition.
        if StaticPopupDialogs then
            StaticPopupDialogs["RRH_CONFIRM_END_SESSION"]={
                text="End the current raid session?\n\nAll remaining loot in the Loot Table will be cleared. The Raid Log will be kept.",
                button1="End Session",
                button2="Cancel",
                timeout=0,
                whileDead=true,
                hideOnEscape=true,
                preferredIndex=3,
                OnAccept=function()
                    if RRH:EndCurrentSession() then
                        UI.selectedLoot=nil
                        UI:Refresh()
                        UI:ShowPage("overview")
                    end
                end
            }
            StaticPopup_Show("RRH_CONFIRM_END_SESSION")
        else
            if RRH:EndCurrentSession() then UI:Refresh() end
        end
    end)
    UI.endSessionButton=endSession

    PageTitle(lootPage,"LOOT MANAGEMENT")

    -- Compact 2.5.2-style loot strip:
    -- Loot is represented by item icons only. Detailed information is shown
    -- through the normal WoW tooltip on mouse-over. This avoids the old
    -- ScrollFrame/layout problems entirely and leaves the roll controls in
    -- their own fixed area below the icons.
    local lootList=CreateFrame("Frame","RRHUILootContent",lootPage)
    lootList:SetPoint("TOPLEFT",16,-58)
    lootList:SetPoint("BOTTOMRIGHT",-16,-184)
    lootList:EnableMouse(true)
    lootList:RegisterForDrag("LeftButton")
    local function HandleLootDrop()
        local cursorType,cursorId,cursorLink=GetCursorInfo()
        if cursorType ~= "item" then return end
        local link=cursorLink
        if not link and cursorId and GetItemInfo then
            local _,itemLink=GetItemInfo(cursorId)
            link=itemLink
        end
        if link and TryHandleManualLootDrop then
            local ok=TryHandleManualLootDrop(link)
            if ok then
                ClearCursor()
                UI:RenderLoot()
                UI:Refresh()
            end
        end
    end
    lootList:SetScript("OnReceiveDrag",HandleLootDrop)
    lootList:SetScript("OnMouseUp",function(self,button)
        if button=="LeftButton" then
            local cursorType=GetCursorInfo()
            if cursorType=="item" then HandleLootDrop() end
        end
    end)
    UI.lootList=lootList

    local bottom=MakePanel(lootPage,690,160)
    bottom:SetPoint("BOTTOMLEFT",16,16)
    local tl=MakeFont(bottom,"Set Tokens:",11); tl:SetPoint("TOPLEFT",16,-16)
    local tokenEdit=CreateFrame("EditBox",nil,bottom,"InputBoxTemplate")
    tokenEdit:SetWidth(55); tokenEdit:SetHeight(25); tokenEdit:SetPoint("TOPLEFT",86,-12)
    tokenEdit:SetAutoFocus(false)
    UI.tokenEdit=tokenEdit

    local b25=MakeButton(bottom,"Roll 25 sec",105); b25:SetPoint("TOPLEFT",150,-12)
    local b10=MakeButton(bottom,"Roll 15 sec",105); b10:SetPoint("TOPLEFT",265,-12)
    local bt=MakeButton(bottom,"Roll Tokens",105); bt:SetPoint("TOPLEFT",380,-12)
    local bc=MakeButton(bottom,"Cancel Roll",105); bc:SetPoint("TOPLEFT",495,-12)
    local btrade=MakeButton(bottom,"Trade Winner",105); btrade:SetPoint("TOPLEFT",495,-48)
    local bdelete=MakeButton(bottom,"Delete Item",105); bdelete:SetPoint("TOPLEFT",380,-48)
    UI.rollState=MakeFont(bottom,"No roll in progress.",11); UI.rollState:SetPoint("TOPLEFT",16,-82)
    btrade:SetScript("OnClick",function()
        if UI.selectedLoot and RRH:TradeLoot(UI.selectedLoot) then
            UI:Refresh()
        end
    end)
    bdelete:SetScript("OnClick",function()
        if not UI.selectedLoot then
            RRH:Error("Select an item first.")
            return
        end
        local active=RRH_Rolls and RRH_Rolls.active
        if active and tonumber(active.sourceLootId)==tonumber(UI.selectedLoot) then
            RRH:Error("This item has an active roll and cannot be deleted.")
            return
        end
        if RemoveLootItemById and RemoveLootItemById(UI.selectedLoot,"Manually deleted from Loot Table") then
            UI.selectedLoot=nil
            UI.selectedText:SetText("No item selected.")
            UI:RenderLoot()
            UI:Refresh()
            return
        end
        RRH:Error("The selected item could not be removed.")
    end)
    UI.deleteLootButton=bdelete
    UI.selectedText=MakeFont(bottom,"No item selected.",11); UI.selectedText:SetPoint("TOPLEFT",16,-108)
    local lootHint=MakeFont(bottom,"Drag items here to add loot  •  Right-click an item to trade  •  Use Delete Item to remove it",10)
    lootHint:SetPoint("TOPLEFT",16,-136)
    lootHint:SetTextColor(0.55,0.65,0.72)

    local function StartSelected(duration)
        local item=UI.selectedLoot and RRH:GetLoot(UI.selectedLoot)
        if not item then RRH:Error("Select an item first."); return end
        local link = item.itemLink or item.link or item.itemName
        if not link or link == "" then RRH:Error("Selected item has no item link."); return end
        RRH_Rolls.Start(link,duration,item.id)
        UI:Refresh()
    end
    b25:SetScript("OnClick",function() StartSelected(25) end)
    b10:SetScript("OnClick",function() StartSelected(15) end)
    bt:SetScript("OnClick",function()
        local item=UI.selectedLoot and RRH:GetLoot(UI.selectedLoot)
        local count=tonumber(tokenEdit:GetText()) or 0
        if item and count>0 then
            RRH_Rolls.StartToken(item,count,25)
            UI:Refresh()
        else
            RRH:Error("Select an item and enter token count.")
        end
    end)
    bc:SetScript("OnClick",function() RRH_Rolls:Cancel() end)

    PageTitle(logPage,"RAID LOG")
    local older=MakeButton(logPage,"< Older",78,28); older:SetPoint("TOPLEFT",16,-48)
    local newer=MakeButton(logPage,"Newer >",78,28); newer:SetPoint("TOPLEFT",98,-48)
    local logSessionLabel=MakeFont(logPage,"Session: —",10); logSessionLabel:SetPoint("TOPLEFT",184,-55)
    logSessionLabel:SetWidth(92)
    logSessionLabel:SetJustifyH("CENTER")
    UI.logSessionLabel=logSessionLabel
    local deleteLog=MakeButton(logPage,"Delete",62,28); deleteLog:SetPoint("TOPRIGHT",-212,-48)
    local saveLog=MakeButton(logPage,"Save",62,28); saveLog:SetPoint("TOPRIGHT",-144,-48)
    local copyLog=MakeButton(logPage,"Copy",62,28); copyLog:SetPoint("TOPRIGHT",-76,-48)
    local logScroll,logEdit,setLogContent=MakeTextScroll(logPage,"RRHUILogScroll",-82,16)
    UI.logScroll=logScroll
    UI.logEdit=logEdit
    UI.setLogContent=setLogContent
    older:SetScript("OnClick",function() UI:ChangeLogSession(1) end)
    newer:SetScript("OnClick",function() UI:ChangeLogSession(-1) end)
    deleteLog:SetScript("OnClick",function() UI:ConfirmDeleteSelectedLog() end)
    saveLog:SetScript("OnClick",function() UI:SaveCurrentLogSnapshot() end)
    copyLog:SetScript("OnClick",function() UI:CopySelectedLog() end)

    PageTitle(newPage,"NEW RAID SESSION")

    local newPanel=MakePanel(newPage,390,380)
    newPanel:SetPoint("TOPLEFT",18,-58)

    local newIntro=MakeFont(newPanel,
        "Create a named session manually.\nThis session will remain active until you end it.",
        11)
    newIntro:SetPoint("TOPLEFT",18,-20)
    newIntro:SetJustifyH("LEFT")
    newIntro:SetTextColor(0.70,0.76,0.82)

    local nameLabel=MakeFont(newPanel,"Raid / Session name",12)
    nameLabel:SetPoint("TOPLEFT",18,-72)

    local function MakeVisibleEdit(parent, text)
        local e=CreateFrame("EditBox",nil,parent)
        e:SetWidth(350)
        e:SetHeight(30)
        e:SetAutoFocus(false)
        e:SetFont("Fonts\\FRIZQT__.TTF",11,"")
        e:SetTextInsets(8,8,2,2)
        e:SetTextColor(1,1,1)
        e:SetMaxLetters(80)
        e:SetBackdrop({
            bgFile="Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            tile=true, tileSize=16, edgeSize=12,
            insets={left=3,right=3,top=3,bottom=3}
        })
        e:SetBackdropColor(0,0,0,0.92)
        e:SetBackdropBorderColor(0.55,0.35,0.12,1)
        e:SetText(text or "")
        e:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
        return e
    end

    local name=MakeVisibleEdit(newPanel,"")
    name:SetPoint("TOPLEFT",18,-92)

    local create=MakeButton(newPanel,"Create Raid Session",180,34)
    create:SetPoint("TOPLEFT",18,-155)
    create:SetScript("OnClick",function()
        local text=NormalizeSpaces and NormalizeSpaces(name:GetText() or "") or (name:GetText() or "")
        if text=="" then
            RRH:Error("Please enter a raid/session name.")
            name:SetFocus()
            return
        end

        local id=RRH:StartNamedSession(text)
        if id then
            name:SetText("")
            UI:ShowPage("overview")
        end
    end)

    local cancelNew=MakeButton(newPanel,"Cancel",110,34)
    cancelNew:SetPoint("LEFT",create,"RIGHT",10,0)
    cancelNew:SetScript("OnClick",function()
        name:SetText("")
        UI:ShowPage("overview")
    end)

    local newHint=MakeFont(newPanel,
        "Automatic loot assignment is configured in Settings and applies to both automatic and manual sessions.",
        9)
    newHint:SetPoint("TOPLEFT",18,-198)
    newHint:SetWidth(350)
    newHint:SetJustifyH("LEFT")
    newHint:SetTextColor(0.55,0.65,0.72)

    -- Settings page.
    PageTitle(settingsPage,"SETTINGS")
    EnsureDB()
    RRH.settings = DB.settings

    local sound=CreateFrame("CheckButton",nil,settingsPage,"UICheckButtonTemplate")
    sound:SetPoint("TOPLEFT",20,-70)
    sound:SetChecked(DB.settings.soundEnabled ~= false)
    local sl=MakeFont(settingsPage,"Roll Sound",12)
    sl:SetPoint("LEFT",sound,"RIGHT",4,0)
    sound:SetScript("OnClick",function()
        local value=sound:GetChecked() and true or false
        DB.settings.soundEnabled=value
        soundEnabled=value
    end)

    local ann=CreateFrame("CheckButton",nil,settingsPage,"UICheckButtonTemplate")
    ann:SetPoint("TOPLEFT",20,-110)
    ann:SetChecked(DB.settings.announceEnabled ~= false)
    local al=MakeFont(settingsPage,"Announce Loot",12)
    al:SetPoint("LEFT",ann,"RIGHT",4,0)
    ann:SetScript("OnClick",function()
        DB.settings.announceEnabled=ann:GetChecked() and true or false
    end)

    local lg=CreateFrame("CheckButton",nil,settingsPage,"UICheckButtonTemplate")
    lg:SetPoint("TOPLEFT",20,-150)
    lg:SetChecked(DB.settings.logEnabled ~= false)
    local ll=MakeFont(settingsPage,"Save Session Log",12)
    ll:SetPoint("LEFT",lg,"RIGHT",4,0)
    lg:SetScript("OnClick",function()
        local value=lg:GetChecked() and true or false
        DB.settings.logEnabled=value
        logEnabled=value
    end)

    local autoTitle=MakeFont(settingsPage,"AUTOMATIC MASTER-LOOT ASSIGNMENT",14)
    autoTitle:SetPoint("TOPLEFT",20,-205)
    autoTitle:SetTextColor(1.0,0.78,0.25)

    local autoInfo=MakeFont(settingsPage,
        "These settings apply to both automatic raid sessions and manually created sessions.\n" ..
        "Automatic assignment works only when you are the actual Master Looter.",
        9)
    autoInfo:SetPoint("TOPLEFT",20,-226)
    autoInfo:SetWidth(430)
    autoInfo:SetJustifyH("LEFT")
    autoInfo:SetTextColor(0.60,0.68,0.74)

    local autoEnable=CreateFrame("CheckButton",nil,settingsPage,"UICheckButtonTemplate")
    autoEnable:SetPoint("TOPLEFT",18,-270)
    autoEnable:SetWidth(22)
    autoEnable:SetHeight(22)
    local autoEnableText=MakeFont(settingsPage,"Enable automatic loot assignment",10)
    autoEnableText:SetPoint("LEFT",autoEnable,"RIGHT",4,0)

    local autoConfirm=CreateFrame("CheckButton",nil,settingsPage,"UICheckButtonTemplate")
    autoConfirm:SetPoint("TOPLEFT",18,-295)
    autoConfirm:SetWidth(22)
    autoConfirm:SetHeight(22)
    local autoConfirmText=MakeFont(settingsPage,"Show preview before assigning",10)
    autoConfirmText:SetPoint("LEFT",autoConfirm,"RIGHT",4,0)

    local defaults=DB.autoLootDefaults or {}
    autoEnable:SetChecked(defaults.enabled and true or false)
    autoConfirm:SetChecked(defaults.confirm ~= false)

    local function MakeTargetField(labelText,y,value)
        local label=MakeFont(settingsPage,labelText,10)
        label:SetPoint("TOPLEFT",20,y)
        local edit=CreateFrame("EditBox",nil,settingsPage)
        edit:SetWidth(285)
        edit:SetHeight(26)
        edit:SetPoint("TOPLEFT",105,y+2)
        edit:SetAutoFocus(false)
        edit:SetFont("Fonts\\FRIZQT__.TTF",11,"")
        edit:SetTextInsets(8,8,2,2)
        edit:SetTextColor(1,1,1)
        edit:SetMaxLetters(40)
        edit:SetBackdrop({
            bgFile="Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            tile=true,tileSize=16,edgeSize=12,
            insets={left=3,right=3,top=3,bottom=3}
        })
        edit:SetBackdropColor(0,0,0,0.92)
        edit:SetBackdropBorderColor(0.55,0.35,0.12,1)
        edit:SetText(value or "")
        edit:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
        return edit
    end

    local bossTarget=MakeTargetField("Boss-Loot:",-330,defaults.boss)
    local sarosTarget=MakeTargetField("Saros:",-362,defaults.saros)
    local shardTarget=MakeTargetField("Splitter:",-394,defaults.shards)

    local saveAuto=MakeButton(settingsPage,"Save Auto-Loot Settings",190,34)
    saveAuto:SetPoint("TOPLEFT",20,-435)
    saveAuto:SetScript("OnClick",function()
        EnsureDB()
        DB.autoLootDefaults.enabled=autoEnable:GetChecked() and true or false
        DB.autoLootDefaults.confirm=autoConfirm:GetChecked() and true or false
        DB.autoLootDefaults.boss=NormalizeSpaces(bossTarget:GetText() or "")
        DB.autoLootDefaults.saros=NormalizeSpaces(sarosTarget:GetText() or "")
        DB.autoLootDefaults.shards=NormalizeSpaces(shardTarget:GetText() or "")
        Info("RRH: Automatic Master-Loot settings saved.")
    end)

    UI.settingsSound=sound
    UI.settingsAnnounce=ann
    UI.settingsLog=lg
    UI.autoLootEnable=autoEnable
    UI.autoLootConfirm=autoConfirm
    UI.autoLootBoss=bossTarget
    UI.autoLootSaros=sarosTarget
    UI.autoLootShards=shardTarget

    -- Help / Rules page.
    PageTitle(helpPage,"HELP / RULES")
    local helpScroll,helpEdit,setHelpContent=MakeTextScroll(helpPage,"RRHUIHelpScroll",-55,16)
    UI.helpScroll=helpScroll
    UI.helpEdit=helpEdit
    UI.setHelpContent=setHelpContent
    helpEdit:SetFont("Fonts\\FRIZQT__.TTF",11,"")
    helpEdit:SetTextColor(0.90,0.90,0.92,1)
    helpEdit:SetTextInsets(8,8,8,8)
    helpEdit:SetWidth(math.max(1,helpScroll:GetWidth()-12))
    helpEdit:SetHeight(math.max(1,helpScroll:GetHeight()))
    helpEdit:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
    setHelpContent([[
|cffd99bffRAID ROLL HELPER – RISING GODS EDITION|r
|cffaaaaaaWotLK 3.3.5a – Functions and rules|r

|cffffcc00GENERAL RULES|r
• RRH manages the active loot list, rolls and raid log.
• The active session remains active until it is manually ended.
• Ending a session removes remaining loot from the active queue; the historical log remains.
• Automatic sessions are created only inside real raid instances and only for Raid Leader / Assistant.
• Outside raids no automatic session is created.
• Items can also be added manually by dragging them from the inventory into the loot list.

|cffffcc00LOOT RULES|r
• Focus Roll has the highest priority and uses 101–200.
• Main Spec (MS) is the next priority and uses 1–100.
• Off Spec (OS) is the lowest priority and uses 1–99.
• A higher absolute OS roll does not beat an MS or Focus Roll; the priority tier is decisive.
• Within the same priority tier, the highest roll wins.
• If the required number of winners reaches a tie at the cutoff, those tied players enter a reroll.
• A player may not submit a second normal roll once a normal roll is already recorded.
• Focus Roll is limited to two Focus Rolls per player where the active roll permits Focus Rolls.
• In Token Roll, the configured number of token slots is filled according to Focus > MS > OS.
• If only one player has a valid Token Roll, that player receives all token slots.
• Token Roll supports multiple winners and individual token assignment.
• Invalid, duplicate or disallowed rolls are ignored and the same rejection is announced only once per player/reason during that roll.
• A roll can be cancelled by the raid roll controller before it is finalized.
• Loot is only added to the RRH Loot Table while an active RRH session exists.
• Manual deletion removes the item from the live loot table and is recorded in the Raid Log.
• Right-click on a loot item is reserved for the normal trade action.
• RRH does not override Blizzard/Rising Gods loot, soulbind or trade restrictions.

|cffffcc00LOOT & ROLLS|r
• 25-second Roll, 15-second Roll and Token Roll.
• Focus Roll / MS / OS / Multiroll.
• Cancel Roll.
• Winners and roll results are stored in the raid log.

|cffffcc00AUTOMATIC MASTER-LOOT ASSIGNMENT|r
• Configure the target players in Settings.
• Boss-Loot, Primordial Saronite (Saros) and Shadowfrost Shard (Splitter) are supported.
• Settings apply to automatic and manually created sessions.
• Feature is disabled by default.
• Preview/confirmation is enabled by default.
• Works only when you are the actual Master Looter.
• If the target is not currently available as a Master-Loot candidate, the item remains untouched.
• The current loot slot and target player are re-checked immediately before assignment.

|cffffcc00RAID LOG & COPY|r
• Loot, rolls, winners, trades and manual changes are recorded.
• Older / Newer switches between stored session logs.
• Logs can be saved, copied and deleted.
• Copy Raid contains detailed roll results and is scrollable.

|cffffcc00MINIMAP & COMMANDS|r
• Left-click minimap button: open the main RRH window.
• Right-click: change Group Loot / Master Loot when permitted.
• Hold right mouse button: move the minimap button.
• /rrh – open or close the main window.

|cffffcc00IMPORTANT|r
RRH does not change Blizzard's underlying loot/trade restrictions. Server-side behaviour always takes precedence.
]])
    UI.ready=true
end

function UI:RenderLoot()
    local s = RRH:GetSession()
    local children = GetSessionLootItems and GetSessionLootItems(s and s.id or nil) or {}
    local list = self.lootList
    if not list then return end

    local oldChildren = { list:GetChildren() }
    local i
    for i=1,#oldChildren do
        oldChildren[i]:Hide()
        oldChildren[i]:SetParent(nil)
    end

    -- Format the remaining trade time as H:MM:SS, matching the compact
    -- 2.5.2 presentation.
    local function TradeClock(seconds)
        seconds=math.max(0,tonumber(seconds) or 0)
        local h=math.floor(seconds/3600)
        local m=math.floor((seconds%3600)/60)
        local sec=math.floor(seconds%60)
        return string.format("%d:%02d:%02d",h,m,sec)
    end

    local iconSize=40
    local gapX=5
    local gapY=2
    local columns=15

    for i=1,#children do
        local item=children[i]
        local col=(i-1)%columns
        local rowIndex=math.floor((i-1)/columns)

        local button=CreateFrame("Button",nil,list)
        button:SetSize(iconSize,iconSize)
        button:SetPoint("TOPLEFT",col*(iconSize+gapX),-(rowIndex*(iconSize+gapY)))
        button:EnableMouse(true)

        local icon=button:CreateTexture(nil,"ARTWORK")
        icon:SetSize(iconSize,iconSize)
        icon:SetPoint("TOP",0,0)
        icon:SetTexture(item.icon or "Interface\\Icons\\INV_Misc_QuestionMark")

        -- Thin selected highlight.
        local selected=button:CreateTexture(nil,"HIGHLIGHT")
        selected:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
        selected:SetBlendMode("ADD")
        selected:SetAllPoints(icon)

        -- Trade timer is deliberately overlaid below the icon, not in a
        -- separate loot row. It is refreshed by the existing 0.5s UI ticker.
        local timer=MakeFont(button,"",10,"OUTLINE")
        timer:SetPoint("BOTTOM",icon,"BOTTOM",0,0)
        timer:SetWidth(iconSize+8)
        timer:SetJustifyH("CENTER")
        timer:SetTextColor(1.0,0.82,0.25)
        timer:SetShadowOffset(1,-1)

        if item.expiresAt then
            timer:SetText(TradeClock(math.max(0,(tonumber(item.expiresAt) or 0)-time())))
        elseif item.status=="WON" or item.status=="AWARDED" then
            timer:SetText("—")
        else
            timer:SetText("")
        end

        button:SetScript("OnClick",function()
            self.selectedLoot=item.id
            local selectedItem=RRH:GetLoot(item.id)
            if selectedItem then
                self.selectedText:SetText(
                    tostring(selectedItem.itemLink or selectedItem.link or selectedItem.itemName or "Unknown item") ..
                    "  |  " .. tostring(selectedItem.boss or selectedItem.bossName or "Boss")
                )
            end
            self:Refresh()
        end)

        button:SetScript("OnMouseUp",function(self,buttonName)
            if buttonName=="RightButton" then
                -- Right-click is reserved for trading. The player must have
                -- the normal WoW Trade window open with the winner.
                if RRH:TradeLoot(item.id) then
                    UI:Refresh()
                end
            end
        end)

        button:SetScript("OnEnter",function()
            if ShowItemTooltip then
                ShowItemTooltip(button,item)
            elseif GameTooltip then
                GameTooltip:SetOwner(button,"ANCHOR_RIGHT")
                GameTooltip:SetHyperlink(item.itemLink or item.link)
                GameTooltip:Show()
            end
        end)
        button:SetScript("OnLeave",function()
            if HideItemTooltip then
                HideItemTooltip()
            elseif GameTooltip then
                GameTooltip:Hide()
            end
        end)
    end

    if self.selectedLoot then
        local selected=RRH:GetLoot(self.selectedLoot)
        if not selected then
            self.selectedLoot=nil
            self.selectedText:SetText("No item selected.")
        end
    end
end

function UI:GetSortedLogSessionIds()
    if GetSortedSessionIds then return GetSortedSessionIds() end
    local ids={}
    if DB and DB.sessions then
        for id in pairs(DB.sessions) do table.insert(ids,tonumber(id) or id) end
        table.sort(ids,function(a,b) return (tonumber(a) or 0) > (tonumber(b) or 0) end)
    end
    return ids
end

function UI:GetSelectedLogSession()
    local ids=self:GetSortedLogSessionIds()
    if #ids==0 then return nil end
    if self.selectedLogSessionId and DB and DB.sessions[self.selectedLogSessionId] then
        return DB.sessions[self.selectedLogSessionId]
    end
    local current=RRH.currentSession or (DB and DB.currentSessionId and DB.sessions[DB.currentSessionId])
    self.selectedLogSessionId=current and current.id or ids[1]
    return DB and DB.sessions[self.selectedLogSessionId] or nil
end

function UI:ChangeLogSession(direction)
    local ids=self:GetSortedLogSessionIds()
    if #ids==0 then return end
    local current=self:GetSelectedLogSession()
    local pos=1
    for i=1,#ids do
        if tonumber(ids[i])==tonumber(current and current.id) then pos=i break end
    end
    pos=math.max(1,math.min(#ids,pos+(direction or 0)))
    self.selectedLogSessionId=ids[pos]
    self:RenderLog()
end

function UI:BuildSelectedLogText(s)
    if not s then return "No sessions yet." end
    local out={"Raid Roll Helper - "..tostring(s.name or "Raid"),"Session #"..tostring(s.id or ""),"","RAID LOG","========================================",""}
    for i,e in ipairs(s.entries or {}) do
        if e.kind=="loot_removed" then
            table.insert(out,"["..tostring(e.timeText or "").."] DELETED: "..tostring(e.item or "Item"))
            table.insert(out,"  Action: Item manually removed from Loot Table")
            table.insert(out,"  Loot ID: "..tostring(e.lootId or "?"))
            table.insert(out,"")
        else
            table.insert(out,"["..tostring(i).."] "..tostring(e.item or "Item"))
            table.insert(out,"  Winner: "..tostring(e.winner or "?").."  |  Roll: "..tostring(e.winningRoll or e.roll or "?").."  |  Type: "..tostring(e.winningType or e.rollType or "?").."  |  Mode: "..tostring(e.mode or "AUTO"))
            table.insert(out,"  Time: "..tostring(e.dateText or "").." "..tostring(e.timeText or ""))
            for _,r in ipairs(e.rolls or {}) do
                local phase=(r.phase=="reroll") and " [REROLL]" or ""
                table.insert(out,"    "..tostring(r.player or "?").."  "..tostring(r.roll or "?").." "..tostring(r.type or "?")..phase)
            end
            table.insert(out,"")
        end
    end
    if #(s.entries or {})==0 then table.insert(out,"No log entries in this session.") end
    return table.concat(out,"\n")
end

function UI:SaveCurrentLogSnapshot()
    local s=self:GetSelectedLogSession()
    if not s then RRH:Error("No raid log available."); return end
    DB.logSnapshots=DB.logSnapshots or {}
    DB.logSnapshots[s.id]={savedAt=time(),text=self:BuildSelectedLogText(s)}
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff80bfffRRH:|r Log for "..tostring(s.name).." saved to SavedVariables.") end
end

function UI:CopySelectedLog()
    local s=self:GetSelectedLogSession()
    if not s then RRH:Error("No raid log available."); return end
    self.selectedLogSessionId=s.id
    self:ShowPage("copy")
end

function UI:ConfirmDeleteSelectedLog()
    local s=self:GetSelectedLogSession()
    if not s then
        RRH:Error("No raid log selected.")
        return
    end

    if StaticPopupDialogs then
        StaticPopupDialogs["RRH_CONFIRM_DELETE_LOG"]={
            text="Delete raid log for "..tostring(s.name or "this session").."?\n\nThis removes the session history and its saved loot data. This cannot be undone.",
            button1="Delete Log",
            button2="Cancel",
            timeout=0,
            whileDead=true,
            hideOnEscape=true,
            preferredIndex=3,
            OnAccept=function()
                if DB and DB.sessions and DB.sessions[s.id] then
                    if RemoveLootItemsForSession then RemoveLootItemsForSession(s.id) end
                    DB.sessions[s.id]=nil
                    if DB.logSnapshots then DB.logSnapshots[s.id]=nil end
                    if DB.currentSessionId==s.id then DB.currentSessionId=nil end
                    if selectedSessionId==s.id then selectedSessionId=nil end
                    if DB.autoRaidActiveSessionId==s.id then
                        DB.autoRaidActiveSessionId=nil
                        DB.autoRaidActiveZone=nil
                    end
                    if self.selectedLogSessionId==s.id then self.selectedLogSessionId=nil end
                    self:ShowPage("log")
                end
            end
        }
        StaticPopup_Show("RRH_CONFIRM_DELETE_LOG")
    end
end

function UI:RenderLog()
    if not UI.logEdit then return end
    local s=self:GetSelectedLogSession()
    if not s then
        UI.logEdit:SetText("No sessions yet.")
        if UI.logSessionLabel then UI.logSessionLabel:SetText("Session: —") end
        return
    end
    if UI.logSessionLabel then UI.logSessionLabel:SetText("Session: #"..tostring(s.id).."  "..tostring(s.name or "Raid")) end
    local text=self:BuildSelectedLogText(s)
    if UI.setLogContent then UI.setLogContent(text) else UI.logEdit:SetText(text) end
end

function UI:RenderCopy()
    if not UI.copyEdit then return end
    local s=self:GetSelectedLogSession()
    if not s then UI.copyEdit:SetText("No session."); return end

    local out={
        "Raid Roll Helper - "..tostring(s.name or "Raid"),
        "Session #"..tostring(s.id or ""),
        "",
        "DETAILED RAID ROLL LOG",
        "========================================",
        ""
    }

    local i,e,j,r
    for i=1,#(s.entries or {}) do
        e=s.entries[i]
        if e then
            if e.kind=="loot_removed" then
                table.insert(out,"["..tostring(i).."] DELETED: "..tostring(e.item or "Item"))
                table.insert(out,"Action: Manually removed from Loot Table")
                table.insert(out,"Time: "..tostring(e.dateText or "").." "..tostring(e.timeText or ""))
                table.insert(out,"")
            else
                table.insert(out,"["..tostring(i).."] "..tostring(e.item or "Item"))
                table.insert(out,"Winner: "..tostring(e.winner or "?").."  |  Roll: "..tostring(e.winningRoll or e.roll or "?").."  |  Type: "..tostring(e.winningType or e.rollType or "?").."  |  Mode: "..tostring(e.mode or "AUTO"))
                table.insert(out,"Time: "..tostring(e.dateText or "").." "..tostring(e.timeText or ""))
                if #(e.rolls or {})>0 then
                    table.insert(out,"Rolls:")
                    for j=1,#e.rolls do
                        r=e.rolls[j]
                        local phase=(r.phase=="reroll") and " [REROLL]" or ""
                        table.insert(out,"  "..tostring(r.player or "?").."  "..tostring(r.roll or "?").." "..tostring(r.type or "?")..phase)
                    end
                else
                    table.insert(out,"Rolls: No roll data recorded.")
                end
                table.insert(out,"")
            end
        end
    end
    if #(s.entries or {})==0 then table.insert(out,"No loot entries in this session yet.") end

    local text=table.concat(out,"\n")
    if UI.setCopyContent then UI.setCopyContent(text) else UI.copyEdit:SetText(text) end
end

function UI:ShowPage(page)
    if not UI.ready then UI:Build() end
    if not pages[page] then page="overview" end
    UI.page=page
    local k,p
    for k,p in pairs(pages) do p:Hide() end
    pages[page]:Show()
    if page=="loot" then
        UI:RenderLoot()
    elseif page=="log" then
        if not UI.selectedLogSessionId then
            local current=RRH.currentSession or (DB and DB.currentSessionId and DB.sessions[DB.currentSessionId])
            UI.selectedLogSessionId=current and current.id or nil
        end
        UI:RenderLog()
    elseif page=="copy" then
        UI:RenderCopy()
    end
    UI:Refresh()
    Main:Show()
end

function UI:Refresh()
    if not UI.ready then return end

    -- Use the original 2.5.2 backend as the sole authority while actually
    -- inside a raid. Outside a raid the 2.5.2 helper intentionally falls back
    -- to the last saved session; that is useful for the legacy UI but must not
    -- be presented as an active raid in the new UI.
    local inRaid = InRaidGroup and InRaidGroup() or false
    if inRaid and EnsureSessionForLootOrRoll then
        EnsureSessionForLootOrRoll()
    end

    local s = GetCurrentSession and GetCurrentSession() or RRH.currentSession
    if (not inRaid) and s and s.type == "AUTO" then
        s = nil
    end
    RRH.currentSession = s

    if s then
        local lootItems=GetSessionLootItems and GetSessionLootItems(s.id) or {}
        local lootCount=#lootItems
        local pendingCount=0
        local awardedCount=0
        local rollsCompleted=0
        local shortest=nil
        local i,item

        for i=1,#lootItems do
            item=lootItems[i]
            if item then
                if item.status=="PENDING" or item.status=="TRADE PENDING" then
                    pendingCount=pendingCount+1
                elseif item.status=="WON" or item.status=="TRADED" or item.status=="AWARDED" then
                    awardedCount=awardedCount+1
                end
                if item.rolled or item.winner or item.winningRoll then
                    rollsCompleted=rollsCompleted+1
                end
                if item.expiresAt and item.status~="TRADED" then
                    local left=math.max(0,(tonumber(item.expiresAt) or 0)-time())
                    if left>0 and (not shortest or left<shortest) then shortest=left end
                end
            end
        end

        local function FormatOverviewTime(seconds)
            if not seconds then return "—" end
            seconds=math.max(0,math.floor(seconds))
            local h=math.floor(seconds/3600)
            local m=math.floor((seconds%3600)/60)
            local sec=seconds%60
            if h>0 then return string.format("%dh %02dm",h,m) end
            return string.format("%02dm %02ds",m,sec)
        end

        UI.sessionText:SetText("Aktuelle Session: "..tostring(s.name).."  |  Session #"..tostring(s.id).."  |  Raid ID: "..tostring(s.raidInstanceId or s.raidId or "n/a"))
        UI.ovRaid:SetText(tostring(s.name).."  |  Raid ID: "..tostring(s.raidInstanceId or s.raidId or "n/a"))
        UI.ovState:SetText("AKTIV  •  "..tostring(s.dateText or s.date or "").." "..tostring(s.timeText or s.time or ""))
        UI.ovStats:SetText("Loot items: "..tostring(lootCount))
        UI.ovRolls:SetText("Completed rolls: "..tostring(rollsCompleted))
        UI.ovPending:SetText("Pending / tradeable: "..tostring(pendingCount))
        UI.ovAwarded:SetText("Awarded: "..tostring(awardedCount))
        UI.ovMembers:SetText("Raid members: "..tostring(GetNumRaidMembers() or 0))
        UI.ovTrade:SetText("Shortest trade time: "..FormatOverviewTime(shortest))
        if RRH_Rolls.active then
            UI.ovActive:SetText("Active roll: "..math.ceil(tonumber(RRH_Rolls.active.remaining) or 0).."s  •  "..#(RRH_Rolls.active.rolls or {}).." valid rolls")
        else
            UI.ovActive:SetText("Active roll: none")
        end

        local ad=DB and DB.autoLootDefaults or {}
        if ad and ad.enabled then
            UI.ovAuto:SetText(
                "Enabled  •  Boss: "..tostring(ad.boss or "—")..
                "  •  Saros: "..tostring(ad.saros or "—")..
                "  •  Splitter: "..tostring(ad.shards or "—")..
                (ad.confirm ~= false and "  •  Preview: ON" or "  •  Preview: OFF")
            )
        else
            UI.ovAuto:SetText("Disabled  •  Configure targets in Settings")
        end
    else
        UI.sessionText:SetText("Keine aktive Session")
        UI.ovRaid:SetText("Keine aktive Session")
        UI.ovState:SetText("Waiting for raid")
        UI.ovStats:SetText("Loot items: 0")
        UI.ovRolls:SetText("Completed rolls: 0")
        UI.ovPending:SetText("Pending / tradeable: 0")
        UI.ovAwarded:SetText("Awarded: 0")
        UI.ovMembers:SetText("Raid members: "..tostring(GetNumRaidMembers() or 0))
        UI.ovTrade:SetText("Shortest trade time: —")
        UI.ovActive:SetText("Active roll: none")
        local ad=DB and DB.autoLootDefaults or {}
        if ad and ad.enabled then
            UI.ovAuto:SetText(
                "Enabled  •  Boss: "..tostring(ad.boss or "—")..
                "  •  Saros: "..tostring(ad.saros or "—")..
                "  •  Splitter: "..tostring(ad.shards or "—")..
                (ad.confirm ~= false and "  •  Preview: ON" or "  •  Preview: OFF")
            )
        else
            UI.ovAuto:SetText("Disabled  •  Configure targets in Settings")
        end
    end

    if RRH_Rolls.active then
        UI.rollState:SetText("ROLL ACTIVE  •  "..math.ceil(RRH_Rolls.active.remaining).."s  •  "..#RRH_Rolls.active.rolls.." valid rolls")
    else
        UI.rollState:SetText("No roll in progress.")
    end

    if DB and DB.settings then
        if UI.settingsSound then UI.settingsSound:SetChecked(DB.settings.soundEnabled ~= false) end
        if UI.settingsAnnounce then UI.settingsAnnounce:SetChecked(DB.settings.announceEnabled ~= false) end
        if UI.settingsLog then UI.settingsLog:SetChecked(DB.settings.logEnabled ~= false) end
    end
end
local uiEvents=CreateFrame("Frame","RRH_UIEventFrame")
uiEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
uiEvents:RegisterEvent("ADDON_LOADED")
uiEvents:SetScript("OnEvent",function()
    if event=="PLAYER_ENTERING_WORLD" or (event=="ADDON_LOADED" and arg1=="RaidRollHelper_RisingGodsEdition") then
        if not UI.ready then UI:Build() end
        Main:Hide()
        UI:Refresh()
    end
end)

local ticker=CreateFrame("Frame","RRH_UIRefreshTicker")
ticker:SetScript("OnUpdate",function(self,elapsed)
    self.a=(self.a or 0)+elapsed
    if self.a>=0.5 then
        self.a=0
        if UI.ready then UI:Refresh() end
    end
end)



-- UI session refresh bridge. The proven core owns session creation; this
-- bridge only refreshes the single-window presentation when raid state changes.
if not RRH_UI_RaidEventBridge then
    RRH_UI_RaidEventBridge = CreateFrame("Frame")
    RRH_UI_RaidEventBridge:RegisterEvent("PLAYER_ENTERING_WORLD")
    RRH_UI_RaidEventBridge:RegisterEvent("RAID_ROSTER_UPDATE")
    RRH_UI_RaidEventBridge:SetScript("OnEvent", function()
        if not RRH_UI then return end
        if RRH_UI.Refresh then
            -- WotLK 3.3.5a roster/instance state may settle one frame later.
            if RRH_UI._raidRefreshPending then return end
            RRH_UI._raidRefreshPending = true
            local delay = CreateFrame("Frame")
            local elapsed = 0
            delay:SetScript("OnUpdate", function(self, e)
                elapsed = elapsed + e
                if elapsed >= 0.5 then
                    self:SetScript("OnUpdate", nil)
                    self:Hide()
                    RRH_UI._raidRefreshPending = nil
                    RRH_UI:Refresh()
                end
            end)
        end
    end)
end

-- 2.5.2 slash-command compatibility:
-- The original core registers /rrh against ToggleFrameCompat(frame).
-- The legacy frame no longer exists; route the same command to the new UI.
SLASH_RRH1 = "/rrh"
SLASH_RRH2 = "/raidrollhelper"
SlashCmdList["RRH"] = function()
    if RRH_UI and RRH_UI.Toggle then
        RRH_UI:Toggle()
    end
end
