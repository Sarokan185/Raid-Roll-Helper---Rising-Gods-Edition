-- ============================================================
-- RRH_Roll.lua
-- Roll creation, MS/OS/Focus logic, winner handling, rerolls,
-- and roll chat announcements.
-- ============================================================

function GetCountdownMarker(duration)
    duration = tonumber(duration) or DEFAULT_ROLL_TIME
    if duration <= SHORT_ROLL_TIME then
        return 5
    end
    return 10
end

function GetRerollDurationFromBase(baseDuration)
    if tonumber(baseDuration or 0) <= SHORT_ROLL_TIME then
        return SHORT_REROLL_TIME
    end
    return LONG_REROLL_TIME
end

function FinalizeWinner(winner, winningRoll, rollType)
    local wonItem = activeRoll.itemDisplay
    local sourceLootId = activeRoll.sourceLootId
    local sessionId = activeRoll.sessionId

    local typeText = tostring(rollType)
    if rollType == "FOCUS" then
        typeText = "Focus Roll"
    end

    RaidWarn("Congratulations " .. tostring(winner) .. " won " .. tostring(wonItem) .. " with " .. tostring(winningRoll) .. " (" .. typeText .. ")")

    local updated = false
    if sourceLootId then
        local copiedRolls = {}
        local i
        for i = 1, #((activeRoll and activeRoll.rollHistory) or {}) do
            local r = activeRoll.rollHistory[i]
            table.insert(copiedRolls, {
                player = r.player,
                type = r.type,
                roll = r.roll,
                phase = r.phase
            })
        end
        updated = UpdateSessionEntryResult(
            sessionId,
            sourceLootId,
            winner,
            winningRoll,
            rollType,
            activeRoll and activeRoll.mode or "AUTO",
            copiedRolls
        )
    end

    if not updated then
        SaveRollEntryToSession(sessionId, winner, winningRoll, rollType)
    end

    if sourceLootId then
        MarkLootAsWon(sourceLootId, winner, winningRoll, rollType)
    end

    if soundEnabled and PlaySoundFile then
        PlaySoundFile("Sound\\Interface\\LevelUp.wav")
    end

    activeRoll = nil
    ResetActiveInfo()
    RenderLogView()

    if lootFrame and lootFrame:IsShown() then
        RenderLootWindow()
    end
end

function FinalizeTokenRoll(winners)
    if not activeRoll or not activeRoll.tokenMode then
        return
    end

    local sessionId = activeRoll.sessionId
    local tokenLootIds = activeRoll.tokenLootIds or {}
    local tokenCount = activeRoll.tokenTotalCount or activeRoll.tokenCount or #tokenLootIds
    local groupId = activeRoll.tokenGroupId
    local rollHistory = activeRoll.rollHistory or {}
    local tokenOffset = activeRoll.tokenOffset or 0
    local i

    for i = 1, #winners do
        local winner = winners[i]
        local lootId = tokenLootIds[tokenOffset + i]

        if lootId and winner then
            local copiedRolls = {}
            local j
            for j = 1, #rollHistory do
                local r = rollHistory[j]
                table.insert(copiedRolls, {
                    player = r.player,
                    type = r.type,
                    roll = r.roll,
                    phase = r.phase
                })
            end

            local entry = GetLootItemById and GetLootItemById(lootId) or nil
            local updated = false

            if entry then
                updated = UpdateSessionEntryResult(
                    sessionId,
                    lootId,
                    winner.player,
                    winner.roll,
                    winner.type,
                    activeRoll.mode or "TOKEN",
                    copiedRolls
                )
            end

            if not updated then
                SaveRollEntryToSessionForLoot(
                    sessionId,
                    lootId,
                    winner.player,
                    winner.roll,
                    winner.type,
                    activeRoll.mode or "TOKEN",
                    copiedRolls,
                    tokenOffset + i,
                    tokenCount,
                    groupId
                )
            else
                local session = DB and DB.sessions and DB.sessions[sessionId]
                if session and session.entries then
                    local k
                    for k = #session.entries, 1, -1 do
                        local e = session.entries[k]
                        if e and e.lootId == lootId then
                            e.tokenPosition = tokenOffset + i
                            e.tokenCount = tokenCount
                            e.tokenGroupId = groupId
                            break
                        end
                    end
                end
            end

            MarkLootAsWon(
                lootId,
                winner.player,
                winner.roll,
                winner.type,
                tokenOffset + i,
                tokenCount,
                groupId
            )
        end
    end

    local winnerLines = {}
    for i = 1, #winners do
        local w = winners[i]
        local typeText = w.type == "FOCUS" and "Focus Roll" or w.type
        winnerLines[#winnerLines + 1] =
            tostring(i) .. ". " .. tostring(w.player) .. " - " ..
            tostring(w.roll) .. " (" .. tostring(typeText) .. ")"
    end

    RaidWarn("Token Roll complete: " .. tostring(tokenCount) .. "x " .. tostring(activeRoll.itemDisplay))
    for i = 1, #winnerLines do
        RaidWarn(winnerLines[i])
    end

    if soundEnabled and PlaySoundFile then
        PlaySoundFile("Sound\\Interface\\LevelUp.wav")
    end

    activeRoll = nil
    ResetActiveInfo()
    RenderLogView()

    if lootFrame and lootFrame:IsShown() then
        RenderLootWindow()
    end
end


function AnnounceCountdownForRoll(roll)
    if not roll then
        return
    end

    local marker = GetCountdownMarker(roll.duration)

    if roll.duration > marker then
        After(roll.duration - marker, function()
            if not activeRoll or activeRoll ~= roll or activeRoll.waitingStart then
                return
            end
            if marker == 10 then
                RaidWarn("Time left: 10sec " .. tostring(activeRoll.itemDisplay))
            elseif marker == 5 then
                RaidWarn("Roll for: " .. tostring(activeRoll.itemDisplay) .. " ends in 5sec")
            end
        end)
    elseif roll.duration == 15 then
        After(5, function()
            if not activeRoll or activeRoll ~= roll or activeRoll.waitingStart then
                return
            end
            RaidWarn("Roll for: " .. tostring(activeRoll.itemDisplay) .. " ends in 5sec")
        end)
    end

    local sec
    if marker == 10 then
        for sec = 9, 1, -1 do
            After(roll.duration - sec, function()
                if not activeRoll or activeRoll ~= roll or activeRoll.waitingStart then
                    return
                end
                RaidSay("Time left: " .. tostring(sec) .. "sec")
            end)
        end
    else
        for sec = 4, 1, -1 do
            After(roll.duration - sec, function()
                if not activeRoll or activeRoll ~= roll or activeRoll.waitingStart then
                    return
                end
                RaidSay("Time left: " .. tostring(sec) .. "sec")
            end)
        end
    end
end

-- Roll priority:
-- 1. Focus Roll (101-200)
-- 2. Main Spec (1-100)
-- 3. Off Spec (1-99)
-- Focus always wins over MS/OS, regardless of the absolute number.
function GetWinningRollInfo(roll)
    if not roll then
        return 0, {}, nil
    end

    local winners, rerollPlayers, rerollType, remaining =
        GetMultiRollOutcome(roll, 1)

    if #rerollPlayers > 0 then
        local highest = GetBestRollValue(roll[rerollType:lower()][rerollPlayers[1]])
        return highest, rerollPlayers, rerollType, {}, 1
    end

    if #winners == 1 then
        return winners[1].roll, { winners[1].player }, winners[1].type, winners, 0
    end

    return 0, {}, nil, {}, remaining or 0
end

function GetRollOutcome(roll)
    local slotCount = roll and roll.tokenMode and roll.tokenCount or 1
    local winners, rerollPlayers, rerollType, remaining =
        GetMultiRollOutcome(roll, slotCount)

    return winners, rerollPlayers, rerollType, remaining
end


function StartAnnouncedRoll(item, duration, sourceLootId, opts)
    if activeRoll then
        Info("Roll already running")
        return false
    end

    if not DB then
        EnsureDB()
    end

    opts = opts or {}
    item = item ~= "" and item or "Item"
    duration = ClampDuration(duration)

    local sessionId = EnsureSessionForLootOrRoll()
    local isReroll = opts.reroll and true or false
    local rerollType = opts.rerollType or nil
    local tokenMode = opts.tokenMode and true or false
    local tokenCount = NormalizePositiveInteger(opts.tokenCount, 1)

    activeRoll = {
        item = NormalizeItemName(item),
        itemKey = NormalizeItemName(item),
        itemDisplay = item,
        mode = tokenMode and "TOKEN" or "AUTO",
        rollKind = tokenMode and "TOKEN" or "OPEN",
        timeLeft = duration,
        duration = duration,
        baseDuration = opts.baseDuration or duration,
        focus = {},
        ms = {},
        os = {},
        players = {},
        normalRollType = {},
        eligiblePlayers = opts.eligiblePlayers or nil,
        eligibleList = opts.eligibleList or {},
        reroll = isReroll,
        rerollType = rerollType,
        waitingStart = false,
        rollHistory = {},
        sessionId = sessionId,
        sourceLootId = sourceLootId,
        tokenMode = tokenMode,
        tokenCount = tokenCount,
        tokenTotalCount = opts.tokenTotalCount or tokenCount,
        tokenOffset = opts.tokenOffset or 0,
        tokenLootIds = opts.tokenLootIds or {},
        tokenGroupId = opts.tokenGroupId or nil,
        fixedWinners = opts.fixedWinners or {},
        tokenRemaining = opts.tokenRemaining or tokenCount
    }

    if isReroll and rerollType then
        local label = rerollType == "FOCUS" and "Focus Roll" or rerollType
        RaidWarn("Reroll only: " .. JoinNamesSimple(activeRoll.eligibleList or {}) .. " (" .. label .. ")")
    elseif tokenMode then
        RaidWarn(
            "Token Roll for " .. tostring(item) ..
            " (" .. tostring(tokenCount) .. " tokens) Time: " .. tostring(duration) .. "sec"
        )
        RaidWarn("Focus=101-200 MS=1-100 OS=1-99")
        RaidWarn("Token rolls: up to 2 Focus Rolls + 1 normal (MS/OS) roll per player; Focus has priority.")
    else
        RaidWarn("Roll for: " .. tostring(item) .. " Time: " .. tostring(duration) .. "sec")
        RaidWarn("Focus=101-200 MS=1-100 OS=1-99")
        RaidWarn("A second Focus Roll is valid only for players with two assigned Focus Rolls; the higher Focus Roll counts.")
    end

    AnnounceCountdownForRoll(activeRoll)
    UpdateActiveInfoText()

    After(duration, function()
        if not activeRoll then
            return
        end

        local winners, rerollPlayers, winnerType, remaining =
            GetRollOutcome(activeRoll)

        if #rerollPlayers > 0 then
            local rerollNames = GetSortedNames(rerollPlayers)
            local rerollDuration = GetRerollDurationFromBase(activeRoll.baseDuration)
            local savedItem = activeRoll.itemDisplay
            local savedSourceLootId = activeRoll.sourceLootId
            local savedBaseDuration = activeRoll.baseDuration
            local savedSessionId = activeRoll.sessionId
            local savedTokenMode = activeRoll.tokenMode
            local savedTokenCount = remaining
            local savedTokenTotalCount = activeRoll.tokenTotalCount or activeRoll.tokenCount
            local savedTokenLootIds = activeRoll.tokenLootIds
            local savedTokenGroupId = activeRoll.tokenGroupId
            local savedFixedWinners = {}
            local fixedIndex
            for fixedIndex = 1, #(activeRoll.fixedWinners or {}) do
                table.insert(savedFixedWinners, activeRoll.fixedWinners[fixedIndex])
            end
            for fixedIndex = 1, #(winners or {}) do
                table.insert(savedFixedWinners, winners[fixedIndex])
            end
            local savedTokenRemaining = remaining
            local savedTokenOffset = #savedFixedWinners
            local rerollEligible = {}
            local i

            for i = 1, #rerollNames do
                rerollEligible[rerollNames[i]] = true
            end

            RaidWarn("Reroll only: " .. JoinNamesSimple(rerollNames))
            RaidWarn(
                "Reroll type: " ..
                (winnerType == "FOCUS" and "Focus Roll (101-200)" or winnerType) ..
                " | Time: " .. tostring(rerollDuration) .. "sec"
            )

            activeRoll = nil

            StartAnnouncedRoll(savedItem, rerollDuration, savedSourceLootId, {
                reroll = true,
                rerollType = winnerType,
                eligiblePlayers = rerollEligible,
                baseDuration = savedBaseDuration,
                eligibleList = rerollNames,
                tokenMode = savedTokenMode,
                tokenCount = savedTokenCount,
                tokenTotalCount = savedTokenTotalCount,
                tokenOffset = savedTokenOffset,
                tokenLootIds = savedTokenLootIds,
                tokenGroupId = savedTokenGroupId,
                fixedWinners = savedFixedWinners,
                tokenRemaining = savedTokenRemaining
            })
            return
        end

        if activeRoll.tokenMode then
            local combined = {}
            local i

            for i = 1, #(activeRoll.fixedWinners or {}) do
                table.insert(combined, activeRoll.fixedWinners[i])
            end
            for i = 1, #winners do
                table.insert(combined, winners[i])
            end

            local remainingTokens = tonumber(remaining) or 0
            local savedItem = activeRoll.itemDisplay
            local savedSourceLootId = activeRoll.sourceLootId
            local savedBaseDuration = activeRoll.baseDuration
            local savedTokenTotalCount = activeRoll.tokenTotalCount or activeRoll.tokenCount
            local savedTokenLootIds = activeRoll.tokenLootIds
            local savedTokenGroupId = activeRoll.tokenGroupId

            activeRoll.tokenOffset = 0
            FinalizeTokenRoll(combined)

            if remainingTokens > 0 then
                local nextOffset = #combined
                local nextDuration = GetRerollDurationFromBase(savedBaseDuration)

                RaidWarn(
                    "Remaining tokens: " .. tostring(remainingTokens) ..
                    " | Starting a new token roll."
                )

                StartAnnouncedRoll(savedItem, nextDuration, savedSourceLootId, {
                    tokenMode = true,
                    tokenCount = remainingTokens,
                    tokenTotalCount = savedTokenTotalCount,
                    tokenOffset = nextOffset,
                    tokenLootIds = savedTokenLootIds,
                    tokenGroupId = savedTokenGroupId,
                    fixedWinners = combined,
                    tokenRemaining = remainingTokens,
                    baseDuration = savedBaseDuration
                })
            end
            return
        end

        if #winners == 1 then
            FinalizeWinner(winners[1].player, winners[1].roll, winners[1].type)
            return
        end

        RaidWarn("No valid rolls")
        activeRoll = nil
        ResetActiveInfo()
    end)

    return true
end

function StartRoll(item, duration, sourceLootId)
    return StartAnnouncedRoll(item, duration, sourceLootId, {})
end

function StartTokenRoll(item, tokenCount, duration)
    if not item then
        Info("No item selected")
        return false
    end

    tokenCount = NormalizePositiveInteger(tokenCount, 1)
    duration = ClampDuration(duration or DEFAULT_ROLL_TIME)

    local sessionId = GetCurrentLootSessionId and GetCurrentLootSessionId() or nil
    if not sessionId then
        sessionId = EnsureSessionForLootOrRoll()
    end

    local itemKey = item.itemKey or NormalizeItemName(item.itemLink or item.itemName or "")
    local tokenEntries = GetTokenLootEntries(itemKey, sessionId, tokenCount)

    if #tokenEntries < tokenCount then
        Info(
            "Only " .. tostring(#tokenEntries) ..
            " matching unassigned tokens are tracked. Need " ..
            tostring(tokenCount) .. "."
        )
        return false
    end

    local tokenLootIds = BuildTokenLootIdList(tokenEntries)
    local groupId = tostring(time()) .. "-" .. tostring(tokenLootIds[1] or 0)

    return StartAnnouncedRoll(
        item.itemLink or item.itemName or "Item",
        duration,
        tokenLootIds[1],
        {
            tokenMode = true,
            tokenCount = tokenCount,
            tokenTotalCount = tokenCount,
            tokenOffset = 0,
            tokenLootIds = tokenLootIds,
            tokenGroupId = groupId,
            fixedWinners = {}
        }
    )
end


function CancelRoll()
    if not activeRoll then
        Info("No active roll")
        return
    end

    activeRoll = nil
    ClearTimers()
    RaidWarn("The current roll was stopped.")
    ResetActiveInfo()
end
