-- ============================================================
-- RRH_Loot.lua
-- Loot queue, loot numbering, bag tracking, trading, and render
-- helpers for the loot window.
-- ============================================================

function AddLootQueueItemFromLootWindow(itemLink, bossName, lootSource, lootSlot)
    if not DB then
        EnsureDB()
    end

    itemLink = SafeItemLink(itemLink)
    if not itemLink then
        return nil
    end

    if not IsEpicOrLegendaryByLink(itemLink, nil, nil) then
        return nil
    end

    local sessionId = EnsureSessionForLootOrRoll()
    if not sessionId then
        return nil
    end

    local itemKey = NormalizeItemName(itemLink)
    local now = time()
    local i

    -- Deduplicate only the exact loot-window slot from the exact loot-window
    -- event. Two identical items in one boss loot window are two distinct
    -- loot entries and must never be collapsed into one.
    for i = #DB.lootQueue, 1, -1 do
        local existing = DB.lootQueue[i]
        if existing and existing.sessionId == sessionId
            and existing.itemKey == itemKey
            and existing.lootWindowCaptureToken == RRH_CurrentLootWindowCaptureToken
            and existing.lootWindowSlot == lootSlot then
            return existing
        end
    end

    local dateText, timeText = GetDateTimeStrings()
    local id = DB.nextLootId
    local entry = {
        id = id,
        uniqueKey = BuildLootUniqueKey(itemLink, now),
        itemLink = itemLink,
        itemName = GetItemNameFromLink(itemLink),
        itemKey = itemKey,
        itemId = GetItemIdFromLink(itemLink),
        icon = GetLootIconTexture(itemLink, nil, nil) or "Interface\\Icons\\INV_Misc_QuestionMark",
        lootedAt = now,
        expiresAt = now + (tradeRemaining or LOOT_TRADE_WINDOW_SECONDS),
        dateText = dateText,
        timeText = timeText,
        status = "PENDING",
        rolled = false,
        winner = nil,
        winningRoll = nil,
        winningType = nil,
        awardedAt = nil,
        awardedDateText = nil,
        awardedTimeText = nil,
        sessionId = sessionId,
        lootNumber = AllocateSessionLootNumber(sessionId),
        sourceBag = nil,
        sourceSlot = nil,
        lootSource = lootSource or "MASTER_LOOT",
        bossName = bossName or "Boss",
        lootWindowCaptureToken = RRH_CurrentLootWindowCaptureToken,
        lootWindowSlot = lootSlot
    }

    DB.nextLootId = id + 1
    table.insert(DB.lootQueue, entry)
    SortLootQueue()
    return entry
end

function GetSessionLootItems(sessionId)
    local list = {}
    local i

    if not DB or not DB.lootQueue then
        return list
    end

    for i = 1, #DB.lootQueue do
        local item = DB.lootQueue[i]
        if sessionId == nil or item.sessionId == sessionId then
            table.insert(list, item)
        end
    end

    return list
end

function CleanupExpiredLoot()
    if not DB or not DB.lootQueue then
        return
    end

    local now = time()
    local i

    for i = 1, #DB.lootQueue do
        local item = DB.lootQueue[i]
        if item.expiresAt and item.expiresAt <= now and item.status ~= "WON" and item.status ~= "TRADED" then
            item.status = "NOT TRADEABLE"
        end
    end
end

function SortLootQueue()
    if not DB or not DB.lootQueue then
        return
    end

    table.sort(DB.lootQueue, function(a, b)
        local aSession = a.sessionId or 0
        local bSession = b.sessionId or 0
        if aSession ~= bSession then
            return aSession < bSession
        end

        local aNumber = a.lootNumber or 0
        local bNumber = b.lootNumber or 0
        if aNumber ~= bNumber then
            return aNumber < bNumber
        end

        local aLoot = a.lootedAt or 0
        local bLoot = b.lootedAt or 0
        if aLoot ~= bLoot then
            return aLoot < bLoot
        end

        return (a.id or 0) < (b.id or 0)
    end)
end

function AllocateSessionLootNumber(sessionId)
    local session
    local nextNumber

    if not DB then
        EnsureDB()
    end

    if not sessionId then
        return nil
    end

    session = DB.sessions and DB.sessions[sessionId]
    if not session then
        return nil
    end

    session.nextLootNumber = tonumber(session.nextLootNumber) or 1
    nextNumber = session.nextLootNumber
    session.nextLootNumber = nextNumber + 1
    return nextNumber
end

function AddLootQueueItem(itemLink, sourceBag, sourceSlot, forceNew)
    if not DB then
        EnsureDB()
    end

    itemLink = SafeItemLink(itemLink)
    if not itemLink then
        return nil
    end

    if not IsEpicOrLegendaryByLink(itemLink, sourceBag, sourceSlot) then
        Info("Item rejected by quality check: " .. tostring(itemLink))
        return nil
    end

    CleanupExpiredLoot()

    local now = time()
    local tradeRemaining = nil
    if sourceBag ~= nil and sourceSlot ~= nil and GetRaidTradeRemainingFromBag then
        tradeRemaining = GetRaidTradeRemainingFromBag(sourceBag, sourceSlot)
    end
    local existingItem = nil
    if not forceNew then
        existingItem = FindBestLootQueueEntryForRebind(itemLink, nil)
    end
    if existingItem
        and existingItem.sessionId == DB.currentSessionId
        and existingItem.itemKey == NormalizeItemName(itemLink)
        and existingItem.sourceBag == nil
        and existingItem.sourceSlot == nil
        and existingItem.status == "PENDING"
        and (existingItem.lootSource == "MASTER_LOOT" or existingItem.lootSource == "GROUP_LOOT") then
        existingItem.sourceBag = sourceBag
        existingItem.sourceSlot = sourceSlot
        existingItem.lootedAt = now
        existingItem.expiresAt = now + (tradeRemaining or LOOT_TRADE_WINDOW_SECONDS)
        existingItem.lootWindowCaptureToken = nil
        RefreshLootBagSlot(existingItem)
        SortLootQueue()
        return existingItem
    end
    local itemName = GetItemNameFromLink(itemLink)
    local dateText, timeText = GetDateTimeStrings()
    local id = DB.nextLootId
    local texture = GetLootIconTexture(itemLink, sourceBag, sourceSlot)
    local sessionId = EnsureSessionForLootOrRoll()
    local lootNumber = AllocateSessionLootNumber(sessionId)

    DB.nextLootId = id + 1

    local entry = {
        id = id,
        uniqueKey = BuildLootUniqueKey(itemLink, now),
        itemLink = itemLink,
        itemName = itemName,
        itemKey = NormalizeItemName(itemLink),
        itemId = GetItemIdFromLink(itemLink),
        icon = texture or "Interface\\Icons\\INV_Misc_QuestionMark",
        lootedAt = now,
        expiresAt = now + LOOT_TRADE_WINDOW_SECONDS,
        dateText = dateText,
        timeText = timeText,
        status = "PENDING",
        rolled = false,
        winner = nil,
        winningRoll = nil,
        winningType = nil,
        awardedAt = nil,
        awardedDateText = nil,
        awardedTimeText = nil,
        sessionId = sessionId,
        lootNumber = lootNumber,
        sourceBag = sourceBag,
        sourceSlot = sourceSlot,
        lootSource = forceNew and "MANUAL" or nil
    }

    table.insert(DB.lootQueue, entry)
    SortLootQueue()
    return entry
end

function RemoveUnboundLootWindowEntries(captureToken)
    if not DB or not DB.lootQueue then return end
    local i = #DB.lootQueue
    while i >= 1 do
        local item = DB.lootQueue[i]
        if item and item.lootWindowCaptureToken == captureToken
            and item.sourceBag == nil and item.sourceSlot == nil
            and item.status == "PENDING" then
            table.remove(DB.lootQueue, i)
        end
        i = i - 1
    end
    SortLootQueue()
end

function GetLootQueueCount(sessionId)
    return #GetSessionLootItems(sessionId)
end

function GetCurrentSessionItemCount(sessionId)
    return GetLootQueueCount(sessionId or (DB and DB.currentSessionId or nil))
end

function GetLootItemBySortedIndex(sortedIndex, sessionId)
    local items = GetSessionLootItems(sessionId)
    return items[sortedIndex]
end

function GetLootItemById(id)
    local i

    if not DB or not DB.lootQueue or not id then
        return nil, nil
    end

    for i = 1, #DB.lootQueue do
        if DB.lootQueue[i].id == id then
            return DB.lootQueue[i], i
        end
    end

    return nil, nil
end

function RemoveLootItemByIndex(index)
    if not DB or not DB.lootQueue or not index then
        return false
    end

    local item=DB.lootQueue[index]
    if not item then
        return false
    end

    table.remove(DB.lootQueue, index)
    return true
end

function RemoveLootItemById(lootId, reason)
    if not DB then
        EnsureDB()
    end
    if not DB or not DB.lootQueue or not lootId then
        return false
    end

    local item, index = GetLootItemById(lootId)
    if not item or not index then
        return false
    end

    -- Keep the deletion in the historical raid log. This is deliberately
    -- independent of the old loot-window rendering code.
    local sessionId=item.sessionId or DB.currentSessionId
    local session=sessionId and DB.sessions and DB.sessions[sessionId] or nil
    if session then
        session.entries=session.entries or {}
        local dateText,timeText=GetDateTimeStrings()
        table.insert(session.entries,{
            kind="loot_removed",
            lootId=item.id,
            item=item.itemLink or item.itemName or item.itemKey or "Item",
            itemKey=item.itemKey or "",
            reason=reason or "Manually deleted from Loot Table",
            dateText=dateText,
            timeText=timeText
        })
    end

    table.remove(DB.lootQueue,index)

    if selectedLootIndex==index then
        selectedLootIndex=nil
    end

    return true
end

function ClearAllLootItems()
    if not DB then
        EnsureDB()
    end

    DB.lootQueue = {}
    selectedLootIndex = nil
end

function MarkLootAsWon(lootId, winner, winningRoll, rollType, tokenPosition, tokenCount, tokenGroupId)
    local item = GetLootItemById(lootId)
    if not item then
        return false
    end

    local dateText, timeText = GetDateTimeStrings()

    item.rolled = true
    item.status = "WON"
    item.winner = winner
    item.winningRoll = winningRoll
    item.winningType = rollType
    item.awardedAt = time()
    item.awardedDateText = dateText
    item.awardedTimeText = timeText

    if tokenGroupId then
        item.tokenGroupId = tokenGroupId
        item.tokenPosition = tokenPosition
        item.tokenCount = tokenCount
    end

    return true
end

function RefreshLootBagSlot(item)
    if not item then
        return
    end

    local currentLink = nil

    if item.sourceBag ~= nil and item.sourceSlot ~= nil and GetContainerItemLink then
        currentLink = GetContainerItemLink(item.sourceBag, item.sourceSlot)
        if currentLink and NormalizeItemName(currentLink) == item.itemKey then
            item.itemLink = currentLink
            item.itemName = GetItemNameFromLink(currentLink)
            item.icon = GetLootIconTexture(currentLink, item.sourceBag, item.sourceSlot)
            return
        end
    end

    local bag, slot = FindBagSlotByExactLink(item.itemLink)
    if bag ~= nil and slot ~= nil then
        item.sourceBag = bag
        item.sourceSlot = slot
        currentLink = GetContainerItemLink and GetContainerItemLink(bag, slot)
        if currentLink then
            item.itemLink = currentLink
            item.itemName = GetItemNameFromLink(currentLink)
            item.icon = GetLootIconTexture(currentLink, bag, slot)
            return
        end
    end

    item.icon = item.icon or GetLootIconTexture(item.itemLink, nil, nil)
    if not item.icon or item.icon == "" then
        item.icon = "Interface\\Icons\\INV_Misc_QuestionMark"
    end
end

function TryTradeLootByIndex(index)
    local item = GetLootItemBySortedIndex(index, GetCurrentLootSessionId())
    if not item then
        return false
    end

    RefreshLootBagSlot(item)

    if not item.winner then
        Info("Roll item first")
        return false
    end

    local ok = TryTradeBagItem(item.sourceBag, item.sourceSlot, item.itemLink)
    if ok then
        item.status = "TRADE PENDING"
        pendingTradeLootId = item.id

        if lootFrame and lootFrame:IsShown() then
            RenderLootWindow()
        end
    end

    return ok
end

function GetLootStatusColor(item)
    if not item then
        return 0.4, 0.4, 0.4
    end

    if item.status == "WON" or item.status == "TRADED" then
        return 0.0, 1.0, 0.0
    end

    local left = math.max(0, (item.expiresAt or 0) - time())
    if left <= 0 or item.status == "NOT TRADEABLE" then
        return 1.0, 0.1, 0.1
    end

    return 1.0, 0.82, 0.0
end

function GetSmallestTradeTime(sessionId)
    local items = GetSessionLootItems(sessionId)
    if #items == 0 then
        return nil
    end

    local best = nil
    local i

    for i = 1, #items do
        local item = items[i]
        local left = math.max(0, (item.expiresAt or 0) - time())

        if left > 0 then
            if best == nil or left < best then
                best = left
            end
        end
    end

    return best
end


function UpdateLootDetailPanel()
    if not lootDetailPanel then
        return
    end

    local item = GetLootItemBySortedIndex(selectedLootIndex or 0, GetCurrentLootSessionId())

    if not item then
        lootDetailItemText:SetText("No item selected")
        lootDetailInfoText:SetText("Left click an item above to manage it here.")
        return
    end

    if item.lootNumber then
        lootDetailItemText:SetText("#" .. tostring(item.lootNumber) .. "  " .. tostring(item.itemLink or item.itemName or "Item"))
    else
        lootDetailItemText:SetText(tostring(item.itemLink or item.itemName or "Item"))
    end

    local left = math.max(0, (item.expiresAt or 0) - time())
    local info = "Status: " .. tostring(item.status or "PENDING") ..
        "   Trade left: " .. FormatTimeLeft(left)

    if item.tokenGroupId and item.tokenPosition and item.tokenCount then
        info = info .. "\nToken: " .. tostring(item.tokenPosition) .. "/" .. tostring(item.tokenCount)
    end

    if item.winner and item.winner ~= "" then
        info = info .. "\nWinner: " .. tostring(item.winner) .. " (" .. tostring(item.winningType or "") .. ")"
    end

    lootDetailInfoText:SetText(info)

end

function UpdateLootHeader(session)
    if lootTitleText then
        lootTitleText:SetText(BuildLootWindowTitle(session))
    end

    if not lootHeaderInfoText then
        return
    end

    if not session then
        lootHeaderInfoText:SetText("Items: 0")
        return
    end

    lootHeaderInfoText:SetText("Items: " .. tostring(GetLootQueueCount(session.id)))
end

function RenderLootWindow()
    if not lootFrame or not lootBagArea then
        return
    end

    CleanupExpiredLoot()
    SortLootQueue()

    local session = GetCurrentLootSession()
    local sessionId = session and session.id or nil
    local count = GetLootQueueCount(sessionId)
    local rows = math.max(1, math.ceil(count / LOOT_COLUMNS))
    local contentHeight = rows * LOOT_SLOT_SIZE + math.max(0, rows - 1) * LOOT_SLOT_SPACING + 12
    local visibleHeight = 190 - 12
    local i

    if lootBagScrollChild then
        lootBagScrollChild:SetHeight(math.max(contentHeight, visibleHeight))
    end

    if lootBagScrollBar then
        local maxScroll = math.max(0, contentHeight - visibleHeight)
        lootBagScrollBar:SetMinMaxValues(0, maxScroll)

        if maxScroll <= 0 then
            lootBagScrollBar:Hide()
            lootBagScrollBar:SetValue(0)
        else
            lootBagScrollBar:Show()
            local current = lootBagScrollBar:GetValue() or 0
            if current > maxScroll then
                lootBagScrollBar:SetValue(maxScroll)
            end
        end
    end

    local smallest = GetSmallestTradeTime(sessionId)
    if lootLowestTimeText then
        if smallest then
            lootLowestTimeText:SetText("Lowest trade time: " .. FormatTradeTimeShort(smallest))
        else
            lootLowestTimeText:SetText("No loot for trade")
        end
    end

    UpdateLootHeader(session)

    for i = 1, count do
        local btn = lootSlotButtons[i]

        if not btn then
            btn = CreateFrame("Button", nil, lootBagScrollChild)
            btn:SetWidth(LOOT_SLOT_SIZE)
            btn:SetHeight(LOOT_SLOT_SIZE)
            btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")

            btn:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                edgeSize = 12,
                insets = { left = 2, right = 2, top = 2, bottom = 2 }
            })

            btn.icon = btn:CreateTexture(nil, "ARTWORK")
            btn.icon:SetPoint("TOPLEFT", 2, -2)
            btn.icon:SetPoint("BOTTOMRIGHT", -2, 2)

            btn.timerText = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            btn.timerText:SetPoint("BOTTOM", 0, 2)

            btn.numberText = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            btn.numberText:SetPoint("TOPRIGHT", -3, -3)
            btn.numberText:SetJustifyH("RIGHT")
            btn.numberText:SetTextColor(1.00, 0.82, 0.00)
            btn.numberText:SetShadowOffset(1, -1)
            btn.numberText:SetShadowColor(0, 0, 0, 1)

            btn.selected = btn:CreateTexture(nil, "OVERLAY")
            btn.selected:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
            btn.selected:SetBlendMode("ADD")
            btn.selected:SetAlpha(0.9)
            btn.selected:SetPoint("TOPLEFT", -8, 8)
            btn.selected:SetPoint("BOTTOMRIGHT", 8, -8)
            btn.selected:Hide()

            btn:SetScript("OnClick", function(self, button)
                if button == "LeftButton" then
                    selectedLootIndex = self.index
                    UpdateLootDetailPanel()
                    RenderLootWindow()
                    local clickedItem = GetLootItemBySortedIndex(self.index, GetCurrentLootSessionId())
                elseif button == "RightButton" then
                    TryTradeLootByIndex(self.index)
                end
            end)

            btn:SetScript("OnEnter", function(self)
                local hoverItem = GetLootItemBySortedIndex(self.index, GetCurrentLootSessionId())
                if hoverItem then
                    ShowItemTooltip(self, hoverItem)
                end
            end)

            btn:SetScript("OnLeave", HideItemTooltip)

            lootSlotButtons[i] = btn
        end

        local item = GetLootItemBySortedIndex(i, sessionId)
        local row = math.floor((i - 1) / LOOT_COLUMNS)
        local col = (i - 1) % LOOT_COLUMNS
        local x = col * (LOOT_SLOT_SIZE + LOOT_SLOT_SPACING)
        local y = row * (LOOT_SLOT_SIZE + LOOT_SLOT_SPACING)
        local left = math.max(0, (item.expiresAt or 0) - time())
        local r, g, b = GetLootStatusColor(item)

        RefreshLootBagSlot(item)

        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", lootBagScrollChild, "TOPLEFT", x + 6, -(y + 6))
        btn.index = i

        btn.icon:SetTexture(item.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        btn.icon:Show()

        btn:SetBackdropColor(0.02, 0.02, 0.02, 0.95)
        btn:SetBackdropBorderColor(r, g, b, 1)
        btn.timerText:SetText(FormatTradeTimeShort(left))
        btn.numberText:SetText(item.lootNumber and ("#" .. tostring(item.lootNumber)) or "")

        if selectedLootIndex == i then
            btn.selected:Show()
        else
            btn.selected:Hide()
        end

        btn:Show()
    end

    for i = count + 1, #lootSlotButtons do
        lootSlotButtons[i]:Hide()
    end

    if selectedLootIndex and selectedLootIndex > count then
        selectedLootIndex = nil
    end

    UpdateLootDetailPanel()
end