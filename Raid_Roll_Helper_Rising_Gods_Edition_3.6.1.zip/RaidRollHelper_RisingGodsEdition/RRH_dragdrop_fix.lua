-- ============================================================
-- RRH_dragdrop_fix.lua
-- Manual loot insertion helpers for bag item drag & drop.
-- ============================================================

-- SAFE DRAG & DROP FIX (correct bag/slot check)

function TryHandleManualLootDrop(itemLink, bag, slot)
    local existingItem
    local entry

    if not itemLink or itemLink == "" then
        return false
    end

    if bag == nil or slot == nil then
        -- Manual drag/drop must prefer a bag slot that is not already bound
        -- to another live queue entry. This is important when the same item
        -- exists more than once in the bags.
        if FindUntrackedBagSlotByLink then
            bag, slot = FindUntrackedBagSlotByLink(itemLink)
        elseif FindBagSlotByExactLink then
            bag, slot = FindBagSlotByExactLink(itemLink)
        end
    end

    if bag == nil or slot == nil then
        if Info then
            Info("Could not resolve item bag slot")
        end
        return false
    end

    if IsEpicOrLegendaryByLink and not IsEpicOrLegendaryByLink(itemLink, bag, slot) then
        return false
    end

    if FindLootQueueItemByBagPosition then
        existingItem = FindLootQueueItemByBagPosition(bag, slot)
    elseif DB and DB.lootQueue then
        for _, item in ipairs(DB.lootQueue) do
            if item and item.sourceBag == bag and item.sourceSlot == slot then
                existingItem = item
                break
            end
        end
    end

    if existingItem then
        if existingItem.status == "WON" and ResetLootItemToPending then
            ResetLootItemToPending(existingItem)
            if RefreshLootBagSlot then RefreshLootBagSlot(existingItem) end
            if SortLootQueue then SortLootQueue() end
            if Info then Info("Item reset to pending") end
            return true
        end

        if existingItem.status ~= "REMOVED" and existingItem.status ~= "TRADED" then
            -- The exact same physical bag slot is already represented. Do not
            -- create a second reference to the same item. A different copy of
            -- the same item, however, is explicitly allowed below.
            if Info then Info("This exact item is already in the queue") end
            return false
        end
    end

    -- Manual insertion is deliberately forced to create a fresh queue entry.
    -- It is the recovery path for loot that was missed or deleted, and must
    -- never silently rebind to another identical queue entry.
    entry = AddLootQueueItem(itemLink, bag, slot, true)

    if not entry then return false end

    entry.lootSource = entry.lootSource or "MANUAL"

    if RefreshLootBagSlot then RefreshLootBagSlot(entry) end
    if SortLootQueue then SortLootQueue() end

    return true
end
