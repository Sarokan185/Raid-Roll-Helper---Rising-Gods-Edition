-- ============================================================
-- RRH SafeGuard
-- WotLK 3.3.5a / Rising Gods
--
-- Keeps a previous complete RaidRollHelperDB snapshot in a
-- separate, alphabetically-first SavedVariables file. The main
-- addon can restore from this snapshot if its own SavedVariables
-- file is missing, truncated or structurally incomplete.
-- ============================================================

RRH_SafeGuardDB = RRH_SafeGuardDB or {}

local SAFE_VERSION = 1
local MAIN_ADDON = "RaidRollHelper_RisingGodsEdition"

local function CopyValue(value, seen)
    local valueType = type(value)
    if valueType ~= "table" then
        return value
    end

    seen = seen or {}
    if seen[value] then
        return nil
    end
    seen[value] = true

    local copy = {}
    local k, v
    for k, v in pairs(value) do
        local cv = CopyValue(v, seen)
        if cv ~= nil then
            copy[k] = cv
        end
    end
    seen[value] = nil
    return copy
end

local function BuildSnapshot()
    if not RaidRollHelperDB or type(RaidRollHelperDB) ~= "table" then
        return nil
    end

    -- Functions/userdata are not part of SavedVariables anyway. The
    -- database consists only of serializable primitives/tables.
    local snapshot = CopyValue(RaidRollHelperDB)
    if not snapshot then
        return nil
    end

    snapshot.__rrhSafeGuardVersion = SAFE_VERSION
    snapshot.__rrhSafeGuardSavedAt = time()

    return snapshot
end

function RRH_SafeGuard_Save()
    local snapshot = BuildSnapshot()
    if not snapshot then
        return false
    end

    -- Keep the previous snapshot as a last-resort fallback until the
    -- new snapshot has been fully assembled.
    RRH_SafeGuardDB.previous = RRH_SafeGuardDB.current
    RRH_SafeGuardDB.current = snapshot
    RRH_SafeGuardDB.lastSavedAt = time()
    return true
end

function RRH_SafeGuard_GetBackup()
    if type(RRH_SafeGuardDB) ~= "table" then
        return nil
    end

    local backup = RRH_SafeGuardDB.current
    if type(backup) ~= "table" then
        backup = RRH_SafeGuardDB.previous
    end
    if type(backup) ~= "table" then
        return nil
    end

    return backup
end

function RRH_SafeGuard_IsValidBackup(backup)
    if type(backup) ~= "table" then
        return false
    end
    if type(backup.sessions) ~= "table" then
        return false
    end
    if type(backup.lootQueue) ~= "table" then
        return false
    end
    if tonumber(backup.nextSessionId) == nil then
        return false
    end
    return true
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGOUT")
frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGOUT" then
        RRH_SafeGuard_Save()
    end
end)
