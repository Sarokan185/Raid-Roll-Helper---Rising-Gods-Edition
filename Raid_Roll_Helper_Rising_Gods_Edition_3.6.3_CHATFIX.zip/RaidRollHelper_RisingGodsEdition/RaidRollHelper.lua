-- ============================================================
-- RaidRollHelper.lua
-- Core addon bootstrap, database/session setup, slash commands,
-- utilities, item detection, and saved data management.
-- ============================================================

-- RaidRollHelper.lua (Core)
-- Warmane 3.3.5a
-- Version 2.1.7

ADDON_NAME = "RaidRollHelper_RisingGodsEdition"
ADDON_VERSION = "2.5.2"

activeRoll = nil
soundEnabled = true

-- Compatibility bridge for the original 2.5.2 roll engine.
-- The old UI exposed UpdateActiveInfoText/ResetActiveInfo. The new single
-- window has no legacy ActiveInfo frame, so these functions now synchronize
-- the engine state with RRH_Rolls.active and the new UI rollState field.
function UpdateActiveInfoText()
    RRH_Rolls = RRH_Rolls or {}
    if activeRoll then
        RRH_Rolls.active = {
            remaining = tonumber(activeRoll.timeLeft) or 0,
            rolls = activeRoll.rollHistory or {},
            item = activeRoll.itemDisplay,
            sourceLootId = activeRoll.sourceLootId,
            duration = activeRoll.duration
        }
        if RRH_UI and RRH_UI.rollState then
            RRH_UI.rollState:SetText(
                "ROLL ACTIVE  •  " ..
                tostring(math.ceil(tonumber(activeRoll.timeLeft) or 0)) ..
                "s  •  " ..
                tostring(#(activeRoll.rollHistory or {})) ..
                " valid rolls"
            )
        end
    else
        RRH_Rolls.active = nil
        if RRH_UI and RRH_UI.rollState then
            RRH_UI.rollState:SetText("No roll in progress.")
        end
    end
end

function ResetActiveInfo()
    RRH_Rolls = RRH_Rolls or {}
    RRH_Rolls.active = nil
    if RRH_UI and RRH_UI.rollState then
        RRH_UI.rollState:SetText("No roll in progress.")
    end
end
logEnabled = true
DB = nil

TEXTURE_PATH = "Interface\\AddOns\\RaidRollHelper_RisingGodsEdition\\Textures\\lichking.tga"

DEFAULT_ROLL_TIME = 25
SHORT_ROLL_TIME = 15
LONG_REROLL_TIME = 20
SHORT_REROLL_TIME = 10
MIN_ROLL_TIME = 1
MAX_ROLL_TIME = 60
REROLL_DELAY = 5
SESSION_TIMEOUT_SECONDS = 24 * 60 * 60
LOOT_TRADE_WINDOW_SECONDS = 2 * 60 * 60
MAX_SESSION_HISTORY = 50

LOOT_SLOT_SIZE = 38
LOOT_SLOT_SPACING = 6
LOOT_COLUMNS = 5

frame = nil
logFrame = nil
copyFrame = nil
newRaidFrame = nil
lootFrame = nil

activeInfo = nil
logText = nil
copyEditBox = nil
sc = nil
lc = nil
logTitle = nil
logHeaderInfoText = nil
lootTitleText = nil
newRaidDateText = nil
newRaidEditBox = nil

lootHeaderInfoText = nil
lootBagArea = nil
lootBagScrollFrame = nil
lootBagScrollChild = nil
lootBagScrollBar = nil
lootLowestTimeText = nil
lootSlotButtons = {}
selectedLootIndex = nil

lootDetailItemText = nil
lootDetailInfoText = nil
lootDetailPanel = nil
tokenCountEditBox = nil

selectedSessionId = nil
pendingTradeLootId = nil
bagItemCache = {}
lootRescanTicket = 0

-- LC Winner Window

tradeScanTip = CreateFrame("GameTooltip", "RRHTradeScanTip", UIParent, "GameTooltipTemplate")
tradeScanTip:SetOwner(UIParent, "ANCHOR_NONE")

timers = {}
timerFrame = CreateFrame("Frame")

function ClearTimers()
    timers = {}
end

function After(sec, func)
    table.insert(timers, { time = sec, func = func })
end

function ToggleFrameCompat(f)
    if not f then
        return
    end

    if f:IsShown() then
        f:Hide()
    else
        f:Show()
    end
end

function InRaidGroup()
    return GetNumRaidMembers and GetNumRaidMembers() > 0
end

function InPartyGroup()
    return GetNumPartyMembers and GetNumPartyMembers() > 0
end

function Trim(s)
    s = tostring(s or "")
    s = s:gsub("^%s+", "")
    s = s:gsub("%s+$", "")
    return s
end

function NormalizeSpaces(s)
    s = Trim(s)
    s = s:gsub("%s+", " ")
    return s
end

function StripColorCodes(s)
    s = tostring(s or "")
    s = s:gsub("|c%x%x%x%x%x%x%x%x", "")
    s = s:gsub("|r", "")
    return s
end

function ExtractBracketItem(s)
    local item = s:match("%[(.-)%]")
    if item and item ~= "" then
        return item
    end
    return s
end

function NormalizePlayerName(name)
    name = StripColorCodes(name)
    name = NormalizeSpaces(name)
    return name
end

function NormalizeItemName(item)
    item = StripColorCodes(item)
    item = tostring(item or "")
    item = item:gsub("|Hitem:[^|]+|h", "")
    item = item:gsub("|H[^|]+|h", "")
    item = item:gsub("|h", "")
    item = ExtractBracketItem(item)
    item = NormalizeSpaces(item)
    return item
end

function SafeItemLink(link)
    if not link or link == "" then
        return nil
    end
    return tostring(link)
end

function GetItemIdFromLink(itemLink)
    if not itemLink then
        return nil
    end
    local itemId = tostring(itemLink):match("item:(%d+)")
    return tonumber(itemId)
end

function BuildLootUniqueKey(itemLink, when)
    local itemId = GetItemIdFromLink(itemLink) or 0
    return tostring(itemId) .. "|" .. tostring(when or time())
end

function GetItemNameFromLink(itemLink)
    if not itemLink or itemLink == "" then
        return "Item"
    end

    local name = NormalizeItemName(itemLink)
    if name and name ~= "" then
        return name
    end

    if GetItemInfo then
        local itemName = GetItemInfo(itemLink)
        if itemName and itemName ~= "" then
            return tostring(itemName)
        end
    end

    return "Item"
end

function GetLootIconTexture(itemLink, bag, slot)
    if bag ~= nil and slot ~= nil and GetContainerItemInfo then
        local icon = select(1, GetContainerItemInfo(bag, slot))
        if icon and icon ~= "" then
            return icon
        end
    end

    if itemLink and itemLink ~= "" and GetItemInfo then
        local _, _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(itemLink)
        if itemTexture and itemTexture ~= "" then
            return itemTexture
        end
    end

    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

function GetSortedNames(list)
    table.sort(list, function(a, b)
        return string.lower(a) < string.lower(b)
    end)
    return list
end

function JoinNamesGerman(list)
    local count = #list

    if count == 0 then
        return ""
    elseif count == 1 then
        return list[1]
    elseif count == 2 then
        return list[1] .. " und " .. list[2]
    else
        local text = ""
        local i

        for i = 1, count do
            if i == 1 then
                text = list[i]
            elseif i == count then
                text = text .. " und " .. list[i]
            else
                text = text .. ", " .. list[i]
            end
        end

        return text
    end
end

function JoinNamesSimple(list)
    local out = {}
    local i
    for i = 1, #list do
        out[#out + 1] = tostring(list[i])
    end
    return table.concat(out, " ")
end

function ClampDuration(sec)
    sec = tonumber(sec) or DEFAULT_ROLL_TIME
    if sec < MIN_ROLL_TIME then
        sec = MIN_ROLL_TIME
    end
    if sec > MAX_ROLL_TIME then
        sec = MAX_ROLL_TIME
    end
    return sec
end

function GetDateTimeStrings()
    local t = date("*t")
    local dateText = string.format("%02d.%02d.%04d", t.day, t.month, t.year)
    local timeText = string.format("%02d:%02d", t.hour, t.min)
    return dateText, timeText
end

function SafeGetZoneName()
    local zone = GetRealZoneText() or GetZoneText() or "Unknown"
    zone = NormalizeSpaces(zone)
    if zone == "" then
        zone = "Unknown"
    end
    return zone
end

function ColorGreen(text)
    return "|cff00ff00" .. tostring(text or "") .. "|r"
end


function RaidWarn(msg)
    msg = tostring(msg or "")

    -- WoW 3.3.5 chat treats a pipe as a formatting escape. Replace stray
    -- pipes (for example the separator in "MS | Time") while preserving
    -- valid color, hyperlink, texture and newline escape sequences.
    msg = msg:gsub("|([^cCrRnHhTt])", " - %1")

    if InRaidGroup() then
        if (IsRaidLeader and IsRaidLeader()) or (IsRaidOfficer and IsRaidOfficer()) then
            SendChatMessage(msg, "RAID_WARNING")
        else
            SendChatMessage(msg, "RAID")
        end
    elseif InPartyGroup() then
        SendChatMessage(msg, "PARTY")
    else
        if DEFAULT_CHAT_FRAME then
            DEFAULT_CHAT_FRAME:AddMessage("|cff80bfffRRH:|r " .. msg)
        end
    end
end

function AnnounceMasterLootEpicItems()
    if DB and DB.settings and DB.settings.announceEnabled == false then
        return
    end
    if not InRaidGroup() then
        return
    end

    if not GetLootMethod or not GetNumLootItems or not GetLootSlotInfo or not GetLootSlotLink then
        return
    end

    local lootMethod, masterlooterPartyID, masterlooterRaidID = GetLootMethod()
    if lootMethod ~= "master" then
        return
    end

    -- Only the actual master looter announces the loot. This prevents
    -- duplicate announcements when multiple raid members use RRH.
    local playerName = NormalizePlayerName(UnitName("player") or "")
    local masterName = ""
    if masterlooterRaidID and GetRaidRosterInfo then
        masterName = NormalizePlayerName(GetRaidRosterInfo(masterlooterRaidID) or "")
    elseif masterlooterPartyID and UnitName then
        masterName = NormalizePlayerName(UnitName("party" .. tostring(masterlooterPartyID)) or "")
    end

    if masterName ~= "" and playerName ~= masterName then
        return
    end

    local links = {}
    local i
    for i = 1, GetNumLootItems() do
        local _, _, _, quality = GetLootSlotInfo(i)
        -- Quality 4 = Epic. Legendary (5) is intentionally excluded.
        if quality == 4 then
            local itemLink = GetLootSlotLink(i)
            if itemLink and itemLink ~= "" then
                table.insert(links, itemLink)
            end
        end
    end

    if #links == 0 then
        return
    end

    -- Use the master looter's current target as the boss name.
    -- The target is read at LOOT_OPENED time, i.e. when the loot window opens.
    local bossName = UnitName("target") or "Unbekannter Boss"
    bossName = NormalizeSpaces(bossName)
    if bossName == "" then
        bossName = "Unbekannter Boss"
    end

    -- Send every line separately so each item is guaranteed to appear on
    -- its own line in the raid chat.
    local separator = "--------------------"
    SendChatMessage(separator, "RAID")
    SendChatMessage("Boss-Loot: " .. bossName, "RAID")

    local linkIndex
    for linkIndex = 1, #links do
        SendChatMessage(links[linkIndex], "RAID")
    end

    SendChatMessage(separator, "RAID")
end

function RaidSay(msg)
    msg = tostring(msg or "")

    if InRaidGroup() then
        SendChatMessage(msg, "RAID")
    elseif InPartyGroup() then
        SendChatMessage(msg, "PARTY")
    else
        if DEFAULT_CHAT_FRAME then
            DEFAULT_CHAT_FRAME:AddMessage("|cff80bfffRRH:|r " .. msg)
        end
    end
end

function Info(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cff80bfffRRH:|r " .. tostring(msg))
    end
end

function FormatTimeLeft(seconds)
    seconds = math.max(0, tonumber(seconds) or 0)
    local minutes = math.floor(seconds / 60)
    local secs = math.floor(seconds % 60)
    return string.format("%02d:%02d", minutes, secs)
end

function FormatTradeTimeShort(seconds)
    seconds = math.max(0, tonumber(seconds) or 0)

    local hours = math.floor(seconds / 3600)
    local mins = math.floor((seconds % 3600) / 60)

    if hours > 0 then
        return tostring(hours) .. "h " .. tostring(mins) .. "m"
    end

    return tostring(mins) .. "m"
end

function GetBestRollValue(value)
    if type(value) == "table" then
        local highest = 0
        local i
        for i = 1, #value do
            local roll = tonumber(value[i]) or 0
            if roll > highest then
                highest = roll
            end
        end
        return highest
    end
    return tonumber(value) or 0
end

function GetTopRollInfo(tbl)
    local highest = 0
    local tiedPlayers = {}
    local name, value

    for name, value in pairs(tbl or {}) do
        local roll = GetBestRollValue(value)
        if roll > highest then
            highest = roll
            tiedPlayers = { name }
        elseif roll == highest and highest > 0 then
            table.insert(tiedPlayers, name)
        end
    end

    GetSortedNames(tiedPlayers)
    return highest, tiedPlayers
end

function GetRankedRollCandidates(roll, rollType)
    local source = roll and roll[rollType:lower()] or nil
    local candidates = {}
    local name, value

    for name, value in pairs(source or {}) do
        local best = GetBestRollValue(value)
        if best > 0 then
            table.insert(candidates, {
                player = name,
                roll = best,
                type = rollType
            })
        end
    end

    table.sort(candidates, function(a, b)
        if a.roll ~= b.roll then
            return a.roll > b.roll
        end
        return string.lower(a.player) < string.lower(b.player)
    end)

    return candidates
end

function GetMultiRollOutcome(roll, slotCount)
    slotCount = math.max(1, tonumber(slotCount) or 1)
    local winners = {}
    local remaining = slotCount
    local tierTypes = { "FOCUS", "MS", "OS" }
    local tierIndex

    -- Token rule: when only one player has any valid roll, that player
    -- receives every token in this token roll.
    if roll and roll.tokenMode then
        local participantSet = {}
        local participantCount = 0
        local participantName = nil
        local tier
        local name

        for tierIndex = 1, #tierTypes do
            tier = tierTypes[tierIndex]
            local source = roll[tier:lower()] or {}
            for name, value in pairs(source) do
                if GetBestRollValue(value) > 0 and not participantSet[name] then
                    participantSet[name] = true
                    participantCount = participantCount + 1
                    participantName = name
                end
            end
        end

        if participantCount == 1 and participantName then
            local bestRoll = 0
            local bestType = nil
            for tierIndex = 1, #tierTypes do
                tier = tierTypes[tierIndex]
                local value = roll[tier:lower()] and roll[tier:lower()][participantName]
                local candidate = GetBestRollValue(value)
                if candidate > bestRoll then
                    bestRoll = candidate
                    bestType = tier
                end
            end

            for tierIndex = 1, slotCount do
                table.insert(winners, {
                    player = participantName,
                    roll = bestRoll,
                    type = bestType
                })
            end
            return winners, {}, nil, 0
        end
    end

    for tierIndex = 1, #tierTypes do
        if remaining <= 0 then
            break
        end

        local tier = tierTypes[tierIndex]
        local candidates = GetRankedRollCandidates(roll, tier)

        if #candidates > 0 then
            if #candidates <= remaining then
                local i
                for i = 1, #candidates do
                    table.insert(winners, candidates[i])
                end
                remaining = remaining - #candidates
            else
                local cutoff = candidates[remaining].roll
                local boundary = {}
                local i

                for i = 1, #candidates do
                    if candidates[i].roll == cutoff then
                        table.insert(boundary, candidates[i].player)
                    elseif candidates[i].roll < cutoff then
                        break
                    end
                end

                if #boundary > remaining then
                    return winners, boundary, tier, remaining
                end

                for i = 1, remaining do
                    table.insert(winners, candidates[i])
                end
                remaining = 0
            end
        end
    end

    return winners, {}, nil, 0
end

function ParseRollInput(msg, defaultDuration)
    msg = tostring(msg or "")
    msg = msg:gsub("^%s+", ""):gsub("%s+$", "")

    defaultDuration = ClampDuration(defaultDuration or DEFAULT_ROLL_TIME)

    if msg == "" then
        return "Item", defaultDuration
    end

    local duration, item = msg:match("^(%d+)%s*%+%s*(.+)$")
    if duration and item and item ~= "" then
        return item, ClampDuration(duration)
    end

    duration, item = msg:match("^(%d+)%s+(.+)$")
    if duration and item and item ~= "" then
        return item, ClampDuration(duration)
    end

    return msg, defaultDuration
end

function NormalizePositiveInteger(value, defaultValue)
    local n = tonumber(value)
    if not n then
        return defaultValue or 1
    end
    n = math.floor(n)
    if n < 1 then
        return defaultValue or 1
    end
    return n
end

function GetTokenLootEntries(itemKey, sessionId, count)
    local matches = {}
    if not DB or not DB.lootQueue or not itemKey or not sessionId then
        return matches
    end

    local i
    for i = 1, #DB.lootQueue do
        local item = DB.lootQueue[i]
        if item and item.sessionId == sessionId
            and item.itemKey == itemKey
            and item.status ~= "WON"
            and item.status ~= "TRADED"
            and item.status ~= "NOT TRADEABLE" then
            table.insert(matches, item)
        end
    end

    table.sort(matches, function(a, b)
        local an = a.lootNumber or 0
        local bn = b.lootNumber or 0
        if an ~= bn then
            return an < bn
        end
        local at = a.lootedAt or 0
        local bt = b.lootedAt or 0
        if at ~= bt then
            return at < bt
        end
        return (a.id or 0) < (b.id or 0)
    end)

    if count and #matches > count then
        while #matches > count do
            table.remove(matches)
        end
    end

    return matches
end

function BuildTokenLootIdList(entries)
    local ids = {}
    local i
    for i = 1, #(entries or {}) do
        ids[i] = entries[i].id
    end
    return ids
end

function IsEpicOrLegendaryByLink(itemLink, bag, slot)
    if not itemLink or itemLink == "" then
        return false
    end

    local color = itemLink:match("|c(%x%x%x%x%x%x%x%x)")
    color = color and string.lower(color)
    if color == "ffa335ee" or color == "ffff8000" then
        return true
    end

    if bag ~= nil and slot ~= nil and GetContainerItemInfo then
        local _, _, _, quality = GetContainerItemInfo(bag, slot)
        if quality and (quality == 4 or quality == 5) then
            return true
        end
    end

    if GetItemInfo then
        local _, _, quality = GetItemInfo(itemLink)
        if quality and (quality == 4 or quality == 5) then
            return true
        end
    end

    return false
end

function FindBagSlotByExactLink(itemLink)
    if not itemLink or itemLink == "" then
        return nil, nil
    end

    for bag = 0, 4 do
        local numSlots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        for slot = 1, numSlots do
            local link = GetContainerItemLink and GetContainerItemLink(bag, slot)
            if link and link == itemLink then
                return bag, slot
            end
        end
    end

    local wantedName = NormalizeItemName(itemLink)

    for bag = 0, 4 do
        local numSlots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        for slot = 1, numSlots do
            local link = GetContainerItemLink and GetContainerItemLink(bag, slot)
            if link and NormalizeItemName(link) == wantedName then
                return bag, slot
            end
        end
    end

    return nil, nil
end

function FindFirstEpicLegendaryBagItem()
    for bag = 0, 4 do
        local numSlots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        for slot = 1, numSlots do
            local link = GetContainerItemLink and GetContainerItemLink(bag, slot)
            if link and IsEpicOrLegendaryByLink(link, bag, slot) then
                return link, bag, slot
            end
        end
    end

    return nil, nil, nil
end


function FindUntrackedBagSlotByLink(itemLink)
    if not itemLink or itemLink == "" then
        return nil, nil
    end

    local wantedName = NormalizeItemName(itemLink)
    local bag
    local slot

    for bag = 0, 4 do
        local numSlots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        for slot = 1, numSlots do
            local link = GetContainerItemLink and GetContainerItemLink(bag, slot)
            if link and link == itemLink and not LootQueueHasBagPosition(bag, slot) then
                return bag, slot
            end
        end
    end

    for bag = 0, 4 do
        local numSlots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        for slot = 1, numSlots do
            local link = GetContainerItemLink and GetContainerItemLink(bag, slot)
            if link and NormalizeItemName(link) == wantedName and not LootQueueHasBagPosition(bag, slot) then
                return bag, slot
            end
        end
    end

    return nil, nil
end

function BuildBagCache()
    bagItemCache = {}

    for bag = 0, 4 do
        bagItemCache[bag] = {}
        local numSlots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0

        for slot = 1, numSlots do
            local link = GetContainerItemLink and GetContainerItemLink(bag, slot)
            bagItemCache[bag][slot] = link or false
        end
    end
end

-- After a session is ended, the items from that session may still be sitting
-- in the player's bags.  Snapshotting the bag state prevents the automatic
-- bag scanner from treating those unchanged items as newly looted in the
-- next session.  Explicit Drag & Drop remains unaffected.
function ResetLootTrackingAfterSessionEnd()
    lootRescanTicket = (lootRescanTicket or 0) + 1
    BuildBagCache()
end

function GetRaidTradeRemainingFromBag(bag, slot)
    if bag == nil or slot == nil then
        return nil
    end

    if not tradeScanTip or not tradeScanTip.SetBagItem then
        return nil
    end

    tradeScanTip:ClearLines()
    tradeScanTip:SetBagItem(bag, slot)

    local i
    local tradeable = false
    local totalSeconds = nil

    for i = 1, 20 do
        local leftLine = _G["RRHTradeScanTipTextLeft" .. i]
        if leftLine then
            local text = tostring(leftLine:GetText() or "")
            local lower = string.lower(text)

            -- The exact Blizzard/Rising-Gods wording is locale dependent.
            -- Restrict duration parsing to tooltip lines that actually talk
            -- about the temporary trade permission, so item level/stats do
            -- not accidentally become the trade timer.
            if string.find(lower, "trade", 1, true)
                or string.find(lower, "handeln", 1, true)
                or string.find(lower, "handel", 1, true) then
                tradeable = true

                local h = string.match(lower, "(%d+)%s*[h]" )
                local m = string.match(lower, "(%d+)%s*[m]")
                local sec = string.match(lower, "(%d+)%s*[s]")

                if not h then
                    h = string.match(lower, "(%d+)%s*hours?")
                end
                if not h then
                    h = string.match(lower, "(%d+)%s*hrs?%.?")
                end
                if not h then
                    h = string.match(lower, "(%d+)%s*stunden?")
                end
                if not h then
                    h = string.match(lower, "(%d+)%s*std%.?")
                end

                if not m then
                    m = string.match(lower, "(%d+)%s*minutes?")
                end
                if not m then
                    m = string.match(lower, "(%d+)%s*minuten?")
                end
                if not m then
                    m = string.match(lower, "(%d+)%s*min%.?")
                end

                if not sec then
                    sec = string.match(lower, "(%d+)%s*seconds?")
                end
                if not sec then
                    sec = string.match(lower, "(%d+)%s*sekunden?")
                end
                if not sec then
                    sec = string.match(lower, "(%d+)%s*sek%.?")
                end

                local hNum = tonumber(h) or 0
                local mNum = tonumber(m) or 0
                local sNum = tonumber(sec) or 0
                local parsed = hNum * 3600 + mNum * 60 + sNum
                if parsed > 0 then
                    totalSeconds = parsed
                end
            end
        end
    end

    if totalSeconds and totalSeconds > 0 then
        return totalSeconds
    end

    if tradeable then
        -- If the client exposes the trade permission but not its remaining
        -- duration in the tooltip, keep the historical 2h fallback. This is
        -- only a fallback; whenever the tooltip exposes the current timer,
        -- that exact remaining duration is used.
        return LOOT_TRADE_WINDOW_SECONDS
    end

    return nil
end

function IsRaidTradeableBagItem(bag, slot)
    if bag == nil or slot == nil then
        return false
    end

    return GetRaidTradeRemainingFromBag(bag, slot) ~= nil
end

function LootQueueHasBagPosition(bag, slot)
    local i

    if not DB or not DB.lootQueue then
        return false
    end

    for i = 1, #DB.lootQueue do
        local item = DB.lootQueue[i]
        if item and item.sourceBag == bag and item.sourceSlot == slot
            and item.status ~= "REMOVED" and item.status ~= "TRADED" then
            -- A bag slot can be reused after an item was moved, traded or
            -- deleted. Only regard the position as occupied while the item
            -- currently in that slot still belongs to this queue entry.
            local currentLink = GetContainerItemLink and GetContainerItemLink(bag, slot) or nil
            if currentLink and item.itemKey and NormalizeItemName(currentLink) == item.itemKey then
                return true
            end
        end
    end

    return false
end

function LootQueueHasUniqueKey(uniqueKey)
    local i

    if not DB or not DB.lootQueue or not uniqueKey then
        return false
    end

    for i = 1, #DB.lootQueue do
        if DB.lootQueue[i].uniqueKey == uniqueKey then
            return true
        end
    end

    return false
end

function LootQueueHasItemLink(itemLink)
    local i

    if not DB or not DB.lootQueue or not itemLink then
        return false
    end

    for i = 1, #DB.lootQueue do
        local item = DB.lootQueue[i]
        if item.itemLink == itemLink and item.status ~= "TRADED" then
            return true
        end
    end

    return false
end

function FindBestLootQueueEntryForRebind(itemLink, claimedSlots)
    local i
    local bestItem = nil
    local bestLootTime = nil
    local wantedKey = NormalizeItemName(itemLink)

    if not DB or not DB.lootQueue or not itemLink then
        return nil
    end

    for i = 1, #DB.lootQueue do
        local item = DB.lootQueue[i]
        if item.id ~= pendingTradeLootId and item.status ~= "TRADED" and item.status ~= "REMOVED" then
            if item.itemLink == itemLink or item.itemKey == wantedKey then
                local currentLink = nil
                local currentMatches = false
                local slotKey = nil

                if item.sourceBag ~= nil and item.sourceSlot ~= nil and GetContainerItemLink then
                    currentLink = GetContainerItemLink(item.sourceBag, item.sourceSlot)
                    if currentLink and NormalizeItemName(currentLink) == item.itemKey then
                        currentMatches = true
                        slotKey = tostring(item.sourceBag) .. ":" .. tostring(item.sourceSlot)
                    end
                end

                if (not currentMatches) or (slotKey and claimedSlots and claimedSlots[slotKey]) then
                    if not bestItem or (item.lootedAt or 0) > (bestLootTime or 0) then
                        bestItem = item
                        bestLootTime = item.lootedAt or 0
                    end
                end
            end
        end
    end

    return bestItem
end


function ScheduleLootRescans()
    local delays = { 0, 0.2, 0.7, 1.5, 3.0 }
    local i

    lootRescanTicket = (lootRescanTicket or 0) + 1
    local myTicket = lootRescanTicket

    for i = 1, #delays do
        local delay = delays[i]
        After(delay, function()
            if myTicket ~= lootRescanTicket then
                return
            end
            ScanBagsForNewEpicLoot()
        end)
    end
end

function ScanBagsForNewEpicLoot()
    local bag
    local slot
    local claimedSlots = {}
    local i

    if not DB then
        EnsureDB()
    end

    if not DB or not DB.lootQueue then
        return
    end

    if not DB.currentSessionId or not DB.sessions or not DB.sessions[DB.currentSessionId] then
        return
    end

    for i = 1, #DB.lootQueue do
        local item = DB.lootQueue[i]
        if item and item.status ~= "TRADED" and item.status ~= "REMOVED" and item.id ~= pendingTradeLootId then
            if item.sourceBag ~= nil and item.sourceSlot ~= nil and GetContainerItemLink then
                local currentLink = GetContainerItemLink(item.sourceBag, item.sourceSlot)
                if currentLink and NormalizeItemName(currentLink) == item.itemKey then
                    local slotKey = tostring(item.sourceBag) .. ":" .. tostring(item.sourceSlot)
                    claimedSlots[slotKey] = true
                    RefreshLootBagSlot(item)
                end
            end
        end
    end

    for bag = 0, 4 do
        local numSlots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        bagItemCache[bag] = bagItemCache[bag] or {}

        for slot = 1, numSlots do
            local oldLink = bagItemCache[bag][slot]
            local newLink = GetContainerItemLink and GetContainerItemLink(bag, slot)
            local slotKey = tostring(bag) .. ":" .. tostring(slot)

            if newLink and newLink ~= oldLink and not claimedSlots[slotKey] then
                if IsEpicOrLegendaryByLink(newLink, bag, slot) and IsRaidTradeableBagItem(bag, slot) then
                    local existingItem = FindBestLootQueueEntryForRebind(newLink, claimedSlots)

	    if existingItem and (existingItem.sourceBag == nil or existingItem.sourceSlot == nil) then
            existingItem.sourceBag = bag
            existingItem.sourceSlot = slot
            claimedSlots[slotKey] = true
            RefreshLootBagSlot(existingItem)
		   end
                end
            end
        end
    end

    for bag = 0, 4 do
        local numSlots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        bagItemCache[bag] = bagItemCache[bag] or {}

        for slot = 1, numSlots do
            local oldLink = bagItemCache[bag][slot]
            local newLink = GetContainerItemLink and GetContainerItemLink(bag, slot)
            local slotKey = tostring(bag) .. ":" .. tostring(slot)

            if newLink and newLink ~= oldLink and not claimedSlots[slotKey] then
                if IsEpicOrLegendaryByLink(newLink, bag, slot) and IsRaidTradeableBagItem(bag, slot) then
                    local entry = FindBestLootQueueEntryForRebind(newLink, claimedSlots)

                    if entry and entry.sessionId == DB.currentSessionId
                        and entry.itemKey == NormalizeItemName(newLink)
                        and entry.sourceBag == nil and entry.sourceSlot == nil
                        and (entry.lootSource == "MASTER_LOOT" or entry.lootSource == "GROUP_LOOT") then
                        entry.sourceBag = bag
                        entry.sourceSlot = slot
                        claimedSlots[slotKey] = true
                        RefreshLootBagSlot(entry)
                    else
                        entry = AddLootQueueItem(newLink, bag, slot)
                        if entry then
                            claimedSlots[slotKey] = true
                            RefreshLootBagSlot(entry)
                        end
                    end
                end
            end

            bagItemCache[bag][slot] = newLink or false
        end
    end

    if lootFrame and lootFrame:IsShown() then
        RenderLootWindow()
    end
end

function ShowItemTooltip(owner, item)
    if not owner or not item then
        return
    end

    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")

    if item.sourceBag ~= nil and item.sourceSlot ~= nil and GetContainerItemLink then
        local currentLink = GetContainerItemLink(item.sourceBag, item.sourceSlot)
        if currentLink and NormalizeItemName(currentLink) == item.itemKey then
            GameTooltip:SetBagItem(item.sourceBag, item.sourceSlot)
        elseif item.itemLink and item.itemLink ~= "" then
            GameTooltip:SetHyperlink(item.itemLink)
        else
            GameTooltip:SetText(item.itemName or "Item")
        end
    elseif item.itemLink and item.itemLink ~= "" then
        GameTooltip:SetHyperlink(item.itemLink)
    else
        GameTooltip:SetText(item.itemName or "Item")
    end

    GameTooltip:AddLine(" ")

    if item.status and item.status ~= "" then
        GameTooltip:AddLine("Status: " .. tostring(item.status), 0.9, 0.9, 0.9)
    end

    if item.winner and item.winner ~= "" then
        GameTooltip:AddLine("Winner: " .. tostring(item.winner), 0.4, 1.0, 0.4)
    end

    if item.expiresAt then
        local left = math.max(0, (item.expiresAt or 0) - time())
        GameTooltip:AddLine("Trade left: " .. FormatTimeLeft(left), 1.0, 0.82, 0.25)
    end

    GameTooltip:Show()
end

function HideItemTooltip()
    GameTooltip:Hide()
end

function TryTradeBagItem(bag, slot, itemLink)
    if not TradeFrame or not TradeFrame:IsShown() then
        Info("Open trade window first")
        return false
    end

    if not PickupContainerItem or not GetContainerItemLink then
        Info("Trading via bag slot is not available on this client")
        return false
    end

    if bag == nil or slot == nil then
        bag, slot = FindBagSlotByExactLink(itemLink)
    end

    if bag == nil or slot == nil then
        Info("Bag position unknown for " .. tostring(itemLink or "item"))
        return false
    end

    local currentLink = GetContainerItemLink(bag, slot)
    if not currentLink then
        Info("Item not found in that bag slot")
        return false
    end

    -- Do not use a tooltip-text tradeability check here.  On 3.3.5/Rising
    -- Gods the tooltip wording can differ by client/server locale and a
    -- false negative would prevent an actually tradeable item from ever
    -- reaching the TradeFrame.  PickupContainerItem itself does not bind an
    -- item; the Blizzard trade UI is the authority that accepts/rejects it.
    local tradeSlot = nil
    if TradeFrame_GetAvailableSlot then
        tradeSlot = TradeFrame_GetAvailableSlot()
    end

    if not tradeSlot then
        Info("No free trade slot available.")
        return false
    end

    PickupContainerItem(bag, slot)
    if not CursorHasItem or not CursorHasItem() then
        Info("Could not pick up the item for trade.")
        return false
    end

    -- Use the same path as the stock 3.3.5 TradeFrame: once an item is on
    -- the cursor, ClickTradeButton puts it into the next free trade slot.
    if ClickTradeButton then
        ClickTradeButton(tradeSlot)
    else
        Info("Trade UI is unavailable on this client.")
        PickupContainerItem(bag, slot)
        return false
    end

    local name = GetTradePlayerItemInfo and select(1, GetTradePlayerItemInfo(tradeSlot)) or nil
    if name then
        return true
    end

    -- If the server/client rejected the item, return it to the original bag
    -- slot instead of leaving it stuck on the cursor.
    if CursorHasItem and CursorHasItem() then
        PickupContainerItem(bag, slot)
    end
    Info("The WoW trade window rejected this item.")
    return false
end

function CheckPendingTradeRemoval(finalizeOnClose)
    if not pendingTradeLootId then
        return
    end

    local item, index = GetLootItemById(pendingTradeLootId)

    if not item then
        pendingTradeLootId = nil
        return
    end

    local currentLink = nil
    if item.sourceBag ~= nil and item.sourceSlot ~= nil and GetContainerItemLink then
        currentLink = GetContainerItemLink(item.sourceBag, item.sourceSlot)
    end

    if currentLink and NormalizeItemName(currentLink) == item.itemKey then
        if finalizeOnClose then
            item.status = "WON"
            pendingTradeLootId = nil

            if lootFrame and lootFrame:IsShown() then
                RenderLootWindow()
            end
        end
        return
    end

    if not finalizeOnClose then
        return
    end

    local bag, slot = FindUntrackedBagSlotByLink(item.itemLink)
    if bag ~= nil and slot ~= nil then
        item.sourceBag = bag
        item.sourceSlot = slot
        item.status = "WON"
        RefreshLootBagSlot(item)
        pendingTradeLootId = nil

        if lootFrame and lootFrame:IsShown() then
            RenderLootWindow()
        end
        return
    end

    item.status = "TRADED"
    RemoveLootItemByIndex(index)
    pendingTradeLootId = nil

    if selectedLootIndex and selectedLootIndex > GetLootQueueCount() then
        selectedLootIndex = nil
    end

    if lootFrame and lootFrame:IsShown() then
        RenderLootWindow()
    end
end

local function RRHRestoreFromSafeGuard()
    if not RRH_SafeGuard_GetBackup or not RRH_SafeGuard_IsValidBackup then
        return false
    end

    local backup = RRH_SafeGuard_GetBackup()
    if not RRH_SafeGuard_IsValidBackup(backup) then
        return false
    end

    -- Never overwrite a structurally valid DB merely because a backup exists.
    -- Restoration is only for missing/truncated/incomplete main data.
    if type(RaidRollHelperDB) == "table"
        and type(RaidRollHelperDB.sessions) == "table"
        and type(RaidRollHelperDB.lootQueue) == "table"
        and tonumber(RaidRollHelperDB.nextSessionId) ~= nil then
        return false
    end

    local restored = {}
    local function Copy(v, seen)
        if type(v) ~= "table" then return v end
        seen = seen or {}
        if seen[v] then return nil end
        seen[v] = true
        local c = {}
        for k, val in pairs(v) do
            local cv = Copy(val, seen)
            if cv ~= nil then c[k] = cv end
        end
        seen[v] = nil
        return c
    end

    restored = Copy(backup) or {}
    restored.__rrhRecoveredAt = time()
    restored.__rrhRecoveredFrom = "RRH SafeGuard"
    RaidRollHelperDB = restored

    return true
end

function EnsureDB()
    RRHRestoreFromSafeGuard()
    RaidRollHelperDB = RaidRollHelperDB or {}
    RaidRollHelperDB.settings = RaidRollHelperDB.settings or {}
    RaidRollHelperDB.sessions = RaidRollHelperDB.sessions or {}
    RaidRollHelperDB.nextSessionId = RaidRollHelperDB.nextSessionId or 1
    RaidRollHelperDB.currentSessionId = RaidRollHelperDB.currentSessionId or nil
    RaidRollHelperDB.lootQueue = RaidRollHelperDB.lootQueue or {}
    RaidRollHelperDB.nextLootId = RaidRollHelperDB.nextLootId or 1
    RaidRollHelperDB.autoRaidCounters = RaidRollHelperDB.autoRaidCounters or {}
    RaidRollHelperDB.autoRaidActiveZone = RaidRollHelperDB.autoRaidActiveZone or nil
    RaidRollHelperDB.autoLootDefaults = RaidRollHelperDB.autoLootDefaults or {
        enabled = false,
        confirm = true,
        boss = "",
        saros = "",
        shards = ""
    }
    RaidRollHelperDB.autoRaidActiveSessionId = RaidRollHelperDB.autoRaidActiveSessionId or nil
    RaidRollHelperDB.recovery = RaidRollHelperDB.recovery or {}
    if RaidRollHelperDB.recovery.schema == nil then
        RaidRollHelperDB.recovery.schema = 1
    end
    RaidRollHelperDB.recovery.lastRuntimeCheckpoint = time()
    RaidRollHelperDB.windowState = RaidRollHelperDB.windowState or {}
    RaidRollHelperDB.minimapButton = RaidRollHelperDB.minimapButton or {}
    if RaidRollHelperDB.minimapButton.angle == nil then
        RaidRollHelperDB.minimapButton.angle = 45
    end

    if RaidRollHelperDB.settings.soundEnabled == nil then
        RaidRollHelperDB.settings.soundEnabled = true
    end

    if RaidRollHelperDB.settings.logEnabled == nil then
        RaidRollHelperDB.settings.logEnabled = true
    end

    if RaidRollHelperDB.settings.announceEnabled == nil then
        RaidRollHelperDB.settings.announceEnabled = true
    end

    local migratedSessions = {}
    local id, session

    for id, session in pairs(RaidRollHelperDB.sessions) do
        local numericId = tonumber(id)
        if numericId then
            session.id = numericId
            migratedSessions[numericId] = session
        end
    end

    RaidRollHelperDB.sessions = migratedSessions

    DB = RaidRollHelperDB
    soundEnabled = DB.settings.soundEnabled
    logEnabled = DB.settings.logEnabled
end


local function RRHMarkSessionDirty()
    if not DB then
        return
    end
    DB.recovery = DB.recovery or {}
    DB.recovery.cleanShutdown = false
    DB.recovery.lastRuntimeCheckpoint = time()
end

local function RRHMarkCleanShutdown()
    if not DB then
        return
    end
    DB.recovery = DB.recovery or {}
    DB.recovery.cleanShutdown = true
    DB.recovery.lastCleanShutdown = time()
    DB.recovery.lastRuntimeCheckpoint = time()
end

function GetCurrentSession()
    if not DB or not DB.currentSessionId then
        return nil
    end
    return DB.sessions[DB.currentSessionId]
end

function IsSessionExpired(session)
    if not session then
        return true
    end
    if not session.createdAt then
        return true
    end
    return (time() - session.createdAt) >= SESSION_TIMEOUT_SECONDS
end

function CanReuseCurrentSession()
    local session = GetCurrentSession()
    if not session then
        return false
    end
    return not IsSessionExpired(session)
end

function GetRaidDisplayName(zoneName)
    local map = {
        ["Icecrown Citadel"] = "ICC",
        ["The Ruby Sanctum"] = "RS",
        ["Trial of the Crusader"] = "TOC",
        ["Trial of the Grand Crusader"] = "TOGC",
        ["Ulduar"] = "ULD",
        ["Naxxramas"] = "NAXX",
        ["Vault of Archavon"] = "VOA",
        ["Onyxia's Lair"] = "ONY",
        ["The Eye of Eternity"] = "EOE",
        ["The Obsidian Sanctum"] = "OS"
    }
    return map[zoneName] or zoneName
end

function IsValidAutoRaidZone(zoneName)
    zoneName = NormalizeSpaces(zoneName or "")
    if zoneName == "" or zoneName == "Unknown" or zoneName == "Azeroth" then
        return false
    end

    if IsInInstance then
        local inInstance, instanceType = IsInInstance()
        if inInstance and instanceType == "raid" then
            return true
        end
    end

    if GetInstanceInfo then
        local instanceName, instanceType = GetInstanceInfo()
        if instanceType == "raid" then
            return true
        end
    end

    -- Automatic sessions are intentionally restricted to real raid
    -- instances. Do not use the zone-name as a fallback here: in the
    -- open world, GetRealZoneText() may return names such as "Northrend",
    -- which must never create an automatic session.
    return false
end

function CanCreateAutomaticRaidSession()
    -- Only the raid leader or a raid assistant may start a new automatic
    -- session. Existing active sessions are handled separately and are not
    -- discarded merely because the player's rank changes.
    if not InRaidGroup or not InRaidGroup() then
        return false
    end
    return (IsRaidLeader and IsRaidLeader()) or (IsRaidOfficer and IsRaidOfficer()) or false
end

function GetSessionEntryCount(session)
    if not session or not session.entries then
        return 0
    end
    return #(session.entries)
end

function RemoveLootItemsForSession(sessionId)
    local i
    if not DB or not DB.lootQueue or not sessionId then
        return
    end

    for i = #DB.lootQueue, 1, -1 do
        if DB.lootQueue[i].sessionId == sessionId then
            table.remove(DB.lootQueue, i)
        end
    end

    if pendingTradeLootId then
        local item = GetLootItemById and select(1, GetLootItemById(pendingTradeLootId)) or nil
        if not item then
            pendingTradeLootId = nil
        end
    end
end

function TrimSessionsToLimit()
    local ids
    local i
    if not DB then
        EnsureDB()
    end

    ids = GetSortedSessionIds()
    for i = MAX_SESSION_HISTORY + 1, #ids do
        local oldId = ids[i]
        RemoveLootItemsForSession(oldId)
        if DB.currentSessionId == oldId then
            DB.currentSessionId = nil
        end
        if selectedSessionId == oldId then
            selectedSessionId = nil
        end
        DB.sessions[oldId] = nil
    end
end

function GetCurrentLootSessionId()
    if not DB then
        EnsureDB()
    end

    if DB.currentSessionId and DB.sessions[DB.currentSessionId] then
        return DB.currentSessionId
    end
    if selectedSessionId and DB.sessions[selectedSessionId] then
        return selectedSessionId
    end
    return nil
end

function GetCurrentLootSession()
    local sessionId = GetCurrentLootSessionId()
    if sessionId and DB and DB.sessions then
        return DB.sessions[sessionId]
    end
    return nil
end

function BuildLootWindowTitle(session)
    if not session then
        return "Loot"
    end
    return "Loot from " .. tostring(session.name or ("Raid #" .. tostring(session.id or "?")))
end

function CreateNewSession(sessionType, sessionName, autoKey)
    if not DB then
        EnsureDB()
    end

    local id = tonumber(DB.nextSessionId) or 1
    local dateText, timeText = GetDateTimeStrings()

    if id < 1 or id > MAX_SESSION_HISTORY then
        id = 1
    end
    if DB.sessions[id] then
        RemoveLootItemsForSession(id)
    end

    DB.sessions[id] = {
        id = id,
        type = sessionType,
        name = sessionName,
        autoKey = autoKey,
        dateText = dateText,
        timeText = timeText,
        createdAt = time(),
        entries = {},
        autoLoot = {
            enabled = DB.autoLootDefaults and DB.autoLootDefaults.enabled or false,
            confirm = DB.autoLootDefaults == nil or DB.autoLootDefaults.confirm ~= false,
            boss = DB.autoLootDefaults and DB.autoLootDefaults.boss or "",
            saros = DB.autoLootDefaults and DB.autoLootDefaults.saros or "",
            shards = DB.autoLootDefaults and DB.autoLootDefaults.shards or ""
        }
    }

    DB.nextSessionId = id + 1
    if DB.nextSessionId > MAX_SESSION_HISTORY then
        DB.nextSessionId = 1
    end

    DB.currentSessionId = id
    selectedSessionId = id
    DB.recovery = DB.recovery or {}
    DB.recovery.activeSessionId = id
    DB.recovery.lastRuntimeCheckpoint = time()

    -- Establish a clean bag baseline for the new session. Items already
    -- present in the bags are not new loot; newly appearing items will still
    -- be detected normally.
    if BuildBagCache then
        BuildBagCache()
    end

    TrimSessionsToLimit()
    return id
end

function CreateManualNamedSession(name)
    name = NormalizeSpaces(name)
    if name == "" then
        name = "Manual Raid"
    end

    -- A manually named session is authoritative for the current raid entry.
    -- This prevents the automatic raid detector from immediately replacing it.
    local zoneName, displayName, dateText, autoKey = GetAutoRaidSessionInfo()
    if autoKey then
        DB.autoRaidSuppressedKey = autoKey
        DB.autoRaidActiveZone = nil
        DB.autoRaidActiveSessionId = nil
        rrhRuntimeAutoSessionId = nil
        rrhRuntimeAutoKey = nil
    end

    return CreateNewSession("MANUAL", name, nil)
end

function SetSessionAutoLootConfig(sessionId, enabled, confirm, boss, saros, shards)
    if not DB then EnsureDB() end
    local session = sessionId and DB.sessions and DB.sessions[tonumber(sessionId)] or nil
    if not session then
        return false
    end

    DB.autoLootDefaults.enabled = enabled and true or false
    DB.autoLootDefaults.confirm = confirm ~= false
    DB.autoLootDefaults.boss = NormalizeSpaces(boss or "")
    DB.autoLootDefaults.saros = NormalizeSpaces(saros or "")
    DB.autoLootDefaults.shards = NormalizeSpaces(shards or "")

    session.autoLoot = {
        enabled = DB.autoLootDefaults.enabled,
        confirm = DB.autoLootDefaults.confirm,
        boss = DB.autoLootDefaults.boss,
        saros = DB.autoLootDefaults.saros,
        shards = DB.autoLootDefaults.shards
    }
    return true
end

function GetSessionAutoLootConfig(session)
    if not session then
        return nil
    end
    -- Settings are global configuration and apply to both automatic and
    -- manually created sessions. Keep an old per-session copy only as a
    -- fallback for sessions created by earlier preview builds.
    if DB and DB.autoLootDefaults then
        return DB.autoLootDefaults
    end
    return session.autoLoot
end

function EndCurrentSession(reason)
    if not DB then EnsureDB() end

    local sessionId = DB.currentSessionId or selectedSessionId
    local session = sessionId and DB.sessions and DB.sessions[sessionId] or nil
    if not session then
        return false
    end

    -- Stop a running roll first so it cannot award into an ended session.
    if activeRoll and CancelRoll then
        CancelRoll()
    end

    local dateText, timeText = GetDateTimeStrings()
    session.endedAt = time()
    session.endedDateText = dateText
    session.endedTimeText = timeText
    session.endReason = reason or "Manually ended"

    -- Keep the historical session/log, but remove all still-pending loot.
    if RemoveLootItemsForSession then
        RemoveLootItemsForSession(session.id)
    end

    -- The physical items may remain in the bags after the session ends.
    -- Reset the automatic bag scanner here so they are not imported again
    -- when a new session is created. Manual Drag & Drop is still allowed.
    if ResetLootTrackingAfterSessionEnd then
        ResetLootTrackingAfterSessionEnd()
    end

    -- While still inside the same raid, suppress automatic recreation.
    local zoneName, displayName, dateText2, autoKey = GetAutoRaidSessionInfo()
    if autoKey then
        DB.autoRaidSuppressedKey = autoKey
    end

    DB.autoRaidActiveZone = nil
    DB.autoRaidActiveSessionId = nil
    DB.currentSessionId = nil
    selectedSessionId = nil
    DB.recovery = DB.recovery or {}
    DB.recovery.activeSessionId = nil
    DB.recovery.lastRuntimeCheckpoint = time()
    RRHMarkSessionDirty()
    rrhRuntimeAutoSessionId = nil
    rrhRuntimeAutoKey = nil

    if RRH_UI and RRH_UI.selectedLogSessionId then
        RRH_UI.selectedLogSessionId = session.id
    end

    return true
end

function GetCurrentRaidInstanceId(zoneName)
    if not zoneName or zoneName == "" then
        return nil
    end

    if not GetNumSavedInstances or not GetSavedInstanceInfo then
        return nil
    end

    local i
    for i = 1, GetNumSavedInstances() do
        local name, id, reset, difficulty, locked = GetSavedInstanceInfo(i)

        -- Warmane/WotLK exposes the real saved instance id here once the raid is locked.
        -- We keep the old date fallback below for moments where the id is not available yet.
        if name == zoneName and locked and id then
            return tostring(id)
        end
    end

    return nil
end

-- Runtime auto-session tracking. This is deliberately not persisted in DB:
-- when no real saved-instance ID is available (common before a raid is
-- locked), each new entry into a raid creates a fresh session, while repeated
-- roster/world events during that same entry reuse it.
local rrhRuntimeAutoSessionId = nil
local rrhRuntimeAutoKey = nil

function GetAutoRaidSessionInfo()
    local zoneName = SafeGetZoneName()
    if not IsValidAutoRaidZone(zoneName) then
        return nil
    end

    local instanceName, instanceType
    if GetInstanceInfo then
        instanceName, instanceType = GetInstanceInfo()
    end
    if instanceName and NormalizeSpaces(instanceName) ~= "" then
        zoneName = NormalizeSpaces(instanceName)
    end

    local displayName = GetRaidDisplayName(zoneName)
    local dateText = select(1, GetDateTimeStrings())
    local raidInstanceId = GetCurrentRaidInstanceId(zoneName)
    local counterKey

    -- Primary key: real WoW raid instance id.
    -- Fallback: date based key, so raids still work before an instance id exists.
    if raidInstanceId then
        counterKey = "AUTO|" .. zoneName .. "|RAIDID|" .. tostring(raidInstanceId)
    else
        counterKey = "AUTO|" .. zoneName .. "|DATE|" .. tostring(dateText)
    end

    if not DB.autoRaidCounters[counterKey] then
        DB.autoRaidCounters[counterKey] = 1
    end
    return zoneName, displayName, dateText, counterKey, raidInstanceId
end

function FindReusableAutoRaidSession(autoKey)
    local id, session
    if not DB or not autoKey then
        return nil
    end

    for id, session in pairs(DB.sessions) do
        -- An explicitly ended session must never be reused when the player
        -- enters the same raid again. An active/unended session may still be
        -- restored after /reload or repeated zone/roster events.
        if session.autoKey == autoKey
            and not session.endedAt
            and not IsSessionExpired(session) then
            return id
        end
    end
    return nil
end

function EnsureSessionForLootOrRoll()
    if not DB then
        EnsureDB()
    end

    local currentSession = GetCurrentSession()
    local zoneName, displayName, dateText, autoKey, raidInstanceId = GetAutoRaidSessionInfo()
    local inAutoRaid = (autoKey ~= nil)

    -- Raid membership and raid location are separate concepts on 3.3.5.
    -- After leaving an instance, the raid roster can remain populated for a
    -- short time. Therefore the instance detector, not InRaidGroup(), decides
    -- whether automatic session handling is active.
    if inAutoRaid then
        if not InRaidGroup() then
            -- Being physically inside the raid is required before we create
            -- an automatic session. Keep any already-active session intact;
            -- the normal LOOT/roll path will resolve it once the raid group is
            -- available.
            return nil
        end

        if DB.autoRaidSuppressedKey == autoKey then
            -- The matching raid was explicitly ended. A later re-entry into
            -- the same raid must create a fresh AUTO session. Temporary world
            -- transitions do not clear this marker, so an unended session is
            -- never lost accidentally.
            if DB.currentSessionId and DB.sessions[DB.currentSessionId]
                and not DB.sessions[DB.currentSessionId].endedAt then
                return DB.currentSessionId
            end
            DB.autoRaidSuppressedKey = nil
        end

        -- Persisted active-raid marker: restore the same unended session after
        -- /reload or repeated world/roster events during this same entry.
        if DB.autoRaidActiveZone == zoneName
            and DB.autoRaidActiveSessionId
            and DB.sessions[DB.autoRaidActiveSessionId] then
            local session = DB.sessions[DB.autoRaidActiveSessionId]
            if not session.endedAt then
                session.name = tostring(displayName) .. " " .. tostring(dateText)
                session.dateText = dateText
                session.raidInstanceId = raidInstanceId
                DB.currentSessionId = session.id
                selectedSessionId = session.id
                rrhRuntimeAutoSessionId = session.id
                rrhRuntimeAutoKey = autoKey
                return session.id
            end
        end

        -- Runtime marker prevents duplicate sessions during one continuous
        -- raid entry.
        if rrhRuntimeAutoSessionId and rrhRuntimeAutoKey == autoKey
            and DB.sessions[rrhRuntimeAutoSessionId]
            and not DB.sessions[rrhRuntimeAutoSessionId].endedAt then
            local session = DB.sessions[rrhRuntimeAutoSessionId]
            session.name = tostring(displayName) .. " " .. tostring(dateText)
            session.dateText = dateText
            session.raidInstanceId = raidInstanceId
            DB.currentSessionId = rrhRuntimeAutoSessionId
            selectedSessionId = rrhRuntimeAutoSessionId
            return rrhRuntimeAutoSessionId
        end

        -- A real saved raid-instance ID can identify an existing, unended
        -- session after /reload. An ended session is deliberately excluded.
        if raidInstanceId then
            local existingId = FindReusableAutoRaidSession(autoKey)
            if existingId then
                local session = DB.sessions[existingId]
                if session then
                    session.name = tostring(displayName) .. " " .. tostring(dateText)
                    session.dateText = dateText
                    session.raidInstanceId = raidInstanceId
                end
                DB.currentSessionId = existingId
                selectedSessionId = existingId
                rrhRuntimeAutoSessionId = existingId
                rrhRuntimeAutoKey = autoKey
                DB.autoRaidActiveZone = zoneName
                DB.autoRaidActiveSessionId = existingId
                return existingId
            end
        end

        -- Never create a new automatic session unless the player is
        -- currently raid leader or raid assistant. This prevents ordinary
        -- raid members from creating duplicate sessions on zone/roster
        -- events and keeps session ownership with the raid leadership.
        if not CanCreateAutomaticRaidSession() then
            return nil
        end

        local sessionName = tostring(displayName) .. " " .. tostring(dateText)
        local newId = CreateNewSession("AUTO", sessionName, autoKey)
        if DB.sessions[newId] then
            DB.sessions[newId].raidInstanceId = raidInstanceId
        end
        rrhRuntimeAutoSessionId = newId
        rrhRuntimeAutoKey = autoKey
        DB.autoRaidActiveZone = zoneName
        DB.autoRaidActiveSessionId = newId
        DB.autoRaidSuppressedKey = nil
        return newId
    end

    -- We are temporarily outside the raid instance. DO NOT destroy the
    -- active automatic session here. On WotLK 3.3.5a, PLAYER_ENTERING_WORLD
    --/zone transitions can occur when a player dies, releases and is
    --resurrected at an instance entrance or otherwise crosses an instance
    --boundary briefly. Clearing the session here loses the loot table.
    --
    -- A session is ended only by EndCurrentSession(), which marks it with
    -- endedAt. An unended AUTO session therefore survives temporary exits and
    -- will be restored when the player is back in the same raid.
    if currentSession
        and currentSession.type == "AUTO"
        and not currentSession.endedAt
        and not IsSessionExpired(currentSession)
        and currentSession.id then
        DB.currentSessionId = currentSession.id
        selectedSessionId = currentSession.id
        return currentSession.id
    end

    -- Outside raids there is deliberately no automatic "Random Session".
    -- Only a user-created MANUAL session may remain active.
    if currentSession
        and currentSession.type == "MANUAL"
        and not currentSession.endedAt
        and not IsSessionExpired(currentSession)
        and currentSession.id then
        DB.currentSessionId = currentSession.id
        selectedSessionId = currentSession.id
        return currentSession.id
    end

    -- An explicitly ended session remains ended. Do not create or resurrect
    -- anything merely because the player is outside the raid.
    return nil
end

function RefreshSessionStateFromWorld(event)
    -- Never clear the runtime/session markers merely because the world/zone
    -- changed. A death/release/resurrection sequence can produce world or
    -- instance transitions without representing a new raid session.
    -- EndCurrentSession() is the only operation that ends a session.

    local delay = 1
    if event == "PLAYER_ENTERING_WORLD" then
        delay = 2
    elseif event == "RAID_ROSTER_UPDATE" then
        delay = 1
    end

    After(delay, function()
        if not DB then
            return
        end
        -- Do not clear automatic session state when the player is temporarily
        -- outside the instance or not yet fully restored to the raid roster.
        -- The active session is authoritative until it is explicitly ended.
        CleanupExpiredLoot()
        EnsureSessionForLootOrRoll()
        RenderLogView()
        if lootFrame and lootFrame:IsShown() then
            RenderLootWindow()
        end
    end)
end

function AddRollHistory(player, rollType, rollValue, phase)
    if not activeRoll then
        return
    end
    if not activeRoll.rollHistory then
        activeRoll.rollHistory = {}
    end

    table.insert(activeRoll.rollHistory, {
        player = player,
        type = rollType,
        roll = rollValue,
        phase = phase or "main"
    })
end

function SaveRollEntryToSession(sessionId, winner, winningRoll, rollType)
    if not DB or not logEnabled then
        return
    end

    local session = DB.sessions[sessionId]
    if not session then
        return
    end

    local dateText, timeText = GetDateTimeStrings()
    local entry = {
        kind = "loot",
        lootId = activeRoll and activeRoll.sourceLootId or nil,
        item = activeRoll and (activeRoll.itemDisplay or activeRoll.item) or "Item",
        itemKey = activeRoll and activeRoll.itemKey or "",
        mode = activeRoll and activeRoll.mode or "AUTO",
        winner = winner,
        winningRoll = winningRoll,
        winningType = rollType,
        dateText = dateText,
        timeText = timeText,
        rolls = {},
        tokenPosition = tokenPosition,
        tokenCount = tokenCount,
        tokenGroupId = tokenGroupId
    }

    local i
    for i = 1, #((activeRoll and activeRoll.rollHistory) or {}) do
        local r = activeRoll.rollHistory[i]
        table.insert(entry.rolls, {
            player = r.player,
            type = r.type,
            roll = r.roll,
            phase = r.phase
        })
    end
    table.insert(session.entries, entry)
end


function SaveRollEntryToSessionForLoot(sessionId, lootId, winner, winningRoll, rollType, mode, rolls, tokenPosition, tokenCount, tokenGroupId)
    if not DB or not logEnabled then
        return
    end

    local session = DB.sessions[sessionId]
    if not session then
        return
    end

    local lootItem = GetLootItemById and GetLootItemById(lootId) or nil
    local dateText, timeText = GetDateTimeStrings()
    local entry = {
        kind = "loot",
        lootId = lootId,
        item = lootItem and (lootItem.itemLink or lootItem.itemName) or (activeRoll and (activeRoll.itemDisplay or activeRoll.item) or "Item"),
        itemKey = lootItem and lootItem.itemKey or (activeRoll and activeRoll.itemKey or ""),
        mode = mode or "AUTO",
        winner = winner,
        winningRoll = winningRoll,
        winningType = rollType,
        dateText = dateText,
        timeText = timeText,
        rolls = {},
        tokenPosition = tokenPosition,
        tokenCount = tokenCount,
        tokenGroupId = tokenGroupId
    }

    local i
    for i = 1, #(rolls or {}) do
        local r = rolls[i]
        table.insert(entry.rolls, {
            player = r.player,
            type = r.type,
            roll = r.roll,
            phase = r.phase
        })
    end

    table.insert(session.entries, entry)
end


function UpdateSessionEntryResult(sessionId, lootId, winner, winningRoll, winningType, mode, rolls)
    if not DB or not DB.sessions or not sessionId or not lootId then
        return false
    end

    local session = DB.sessions[sessionId]
    if not session or not session.entries then
        return false
    end

    local dateText, timeText = GetDateTimeStrings()
    local i

    for i = #session.entries, 1, -1 do
        local e = session.entries[i]
        if e and e.lootId == lootId then
            e.winner = winner
            e.winningRoll = winningRoll or 0
            e.winningType = winningType or e.winningType
            if mode then
                e.mode = mode
            end
            e.dateText = dateText
            e.timeText = timeText
            if rolls then
                e.rolls = rolls
            end
            return true
        end
    end

    return false
end

function GetSortedSessionIds()
    local ids = {}
    if not DB then
        return ids
    end

    local id
    for id in pairs(DB.sessions) do
        table.insert(ids, tonumber(id) or id)
    end

    table.sort(ids, function(a, b)
        local sa = DB.sessions[a]
        local sb = DB.sessions[b]
        local ca = sa and tonumber(sa.createdAt) or 0
        local cb = sb and tonumber(sb.createdAt) or 0
        if ca ~= cb then
            return ca > cb
        end
        return (tonumber(a) or 0) > (tonumber(b) or 0)
    end)
    return ids
end

function BuildSessionText(session)
    if not session then
        return "No session selected"
    end

    local lines = {}
    local i

    table.insert(lines, "Raid ID #" .. tostring(session.id) .. " - " .. tostring(session.name))
    if session.raidInstanceId then
        table.insert(lines, "Instance ID: " .. tostring(session.raidInstanceId))
    end
    table.insert(lines, "Type: " .. tostring(session.type))
    table.insert(lines, "Date: " .. tostring(session.dateText))
    table.insert(lines, "Time: " .. tostring(session.timeText))
    table.insert(lines, "Logged Items: " .. tostring(#(session.entries or {})))
    table.insert(lines, "Loot Queue Items: " .. tostring(GetCurrentSessionItemCount(session.id)))
    table.insert(lines, "----------------------------------------")

    for i = 1, #(session.entries or {}) do
        local e = session.entries[i]
        local tokenLabel = ""
        if e.tokenGroupId and e.tokenPosition and e.tokenCount then
            tokenLabel = " [Token " .. tostring(e.tokenPosition) .. "/" .. tostring(e.tokenCount) .. "]"
        end
        table.insert(lines, "[" .. tostring(i) .. "]" .. tokenLabel .. " " .. tostring(e.item))
        table.insert(lines, "  Winner: " .. tostring(e.winner) .. " (" .. tostring(e.winningRoll) .. " " .. tostring(e.winningType) .. ")")
        table.insert(lines, "  Mode: " .. tostring(e.mode))
        table.insert(lines, "  Time: " .. tostring(e.dateText) .. " " .. tostring(e.timeText))

        local j
        for j = 1, #(e.rolls or {}) do
            local r = e.rolls[j]
            local phaseText = ""
            if r.phase == "reroll" then
                phaseText = " [REROLL]"
            end
            table.insert(lines, "    - " .. tostring(r.player) .. ": " .. tostring(r.roll) .. " " .. tostring(r.type) .. phaseText)
        end
        table.insert(lines, "")
    end

    if #(session.entries or {}) == 0 then
        table.insert(lines, "No loot entries in this session yet.")
    end
    return table.concat(lines, "\n")
end

function BuildAllSessionsText()
    if not DB then
        return "No sessions yet"
    end

    local ids = GetSortedSessionIds()
    if #ids == 0 then
        return "No sessions yet"
    end

    local parts = {}
    local i
    for i = 1, #ids do
        table.insert(parts, BuildSessionText(DB.sessions[ids[i]]))
        if i < #ids then
            table.insert(parts, "\n========================================\n")
        end
    end
    return table.concat(parts, "")
end

function BuildSessionSummaryText(session)
    if not session then
        return "No session selected"
    end

    local lines = {}
    local i
    table.insert(lines, "|cff80ff80Raid ID:|r #" .. tostring(session.id))
    if session.raidInstanceId then
        table.insert(lines, "|cff80ff80Instance ID:|r " .. tostring(session.raidInstanceId))
    end
    table.insert(lines, "|cff80ff80Name:|r " .. tostring(session.name))
    table.insert(lines, "|cff80ff80Type:|r " .. tostring(session.type))
    table.insert(lines, "|cff80ff80Date:|r " .. tostring(session.dateText))
    table.insert(lines, "|cff80ff80Time:|r " .. tostring(session.timeText))
    table.insert(lines, "|cff80ff80Logged Items:|r " .. tostring(#(session.entries or {})))
    table.insert(lines, "")

    if #(session.entries or {}) == 0 then
        table.insert(lines, "No items in this session yet.")
        return table.concat(lines, "\n")
    end

    for i = 1, #(session.entries or {}) do
        local e = session.entries[i]
        local tokenLabel = ""
        if e.tokenGroupId and e.tokenPosition and e.tokenCount then
            tokenLabel = " [Token " .. tostring(e.tokenPosition) .. "/" .. tostring(e.tokenCount) .. "]"
        end
        local typeText = e.winningType == "FOCUS" and "Focus Roll" or tostring(e.winningType)
        table.insert(lines, tostring(i) .. "." .. tokenLabel .. " " .. tostring(e.item))
        if tonumber(e.winningRoll or 0) > 0 then
            table.insert(lines, "   " .. tostring(e.winner) .. " won with " .. tostring(e.winningRoll) .. " " .. typeText)
        else
            table.insert(lines, "   " .. tostring(e.winner) .. " won (" .. typeText .. ")")
        end
    end
    return table.concat(lines, "\n")
end

function OpenCopyText(text)
    if not copyFrame or not copyEditBox then
        return
    end
    copyFrame:Show()
    copyEditBox:SetText(text or "")
    copyEditBox:SetFocus()
    copyEditBox:HighlightText()
end

function DeleteSessionById(id)
    if not DB or not id or not DB.sessions[id] then
        return
    end

    DB.sessions[id] = nil
    if DB.currentSessionId == id then
        DB.currentSessionId = nil
    end

    local ids = GetSortedSessionIds()
    if #ids > 0 then
        selectedSessionId = ids[1]
    else
        selectedSessionId = nil
    end
end

function MoveSessionSelection(step)
    local ids = GetSortedSessionIds()
    local i

    if #ids == 0 then
        selectedSessionId = nil
        RenderLogView()
        return
    end

    if not selectedSessionId then
        selectedSessionId = ids[1]
        RenderLogView()
        return
    end

    for i = 1, #ids do
        if ids[i] == selectedSessionId then
            local newIndex = i + step
            if newIndex < 1 then
                newIndex = 1
            end
            if newIndex > #ids then
                newIndex = #ids
            end
            selectedSessionId = ids[newIndex]
            break
        end
    end
    RenderLogView()
end

function SaveWindowState(stateKey, f)
    if not DB or not f then
        return
    end

    DB.windowState = DB.windowState or {}
    local point, _, relativePoint, x, y = f:GetPoint(1)
    DB.windowState[stateKey] = DB.windowState[stateKey] or {}
    DB.windowState[stateKey].point = point
    DB.windowState[stateKey].relativePoint = relativePoint
    DB.windowState[stateKey].x = x
    DB.windowState[stateKey].y = y
    DB.windowState[stateKey].width = f:GetWidth()
    DB.windowState[stateKey].height = f:GetHeight()
end

function RestoreWindowState(stateKey, f, defaultWidth, defaultHeight)
    if not DB or not f then
        return
    end

    local st = DB.windowState and DB.windowState[stateKey]
    if not st then
        f:SetWidth(defaultWidth)
        f:SetHeight(defaultHeight)
        return
    end

    f:SetWidth(st.width or defaultWidth)
    f:SetHeight(st.height or defaultHeight)
    f:ClearAllPoints()
    f:SetPoint(st.point or "CENTER", UIParent, st.relativePoint or st.point or "CENTER", st.x or 0, st.y or 0)
end

function MakeFrameResizable(f, stateKey, minW, minH)
    if not f then
        return
    end

    f:SetResizable(true)
    f:SetMinResize(minW or 200, minH or 120)

    local grip = CreateFrame("Button", nil, f)
    grip:SetWidth(16)
    grip:SetHeight(16)
    grip:SetPoint("BOTTOMRIGHT", -8, 8)

    local tex = grip:CreateTexture(nil, "ARTWORK")
    tex:SetAllPoints(grip)
    tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")

    grip:SetScript("OnMouseDown", function()
        f:StartSizing("BOTTOMRIGHT")
    end)

    grip:SetScript("OnMouseUp", function()
        f:StopMovingOrSizing()
        SaveWindowState(stateKey, f)
        if stateKey == "loot" and lootFrame and lootFrame:IsShown() then
            RenderLootWindow()
        end
    end)

    grip:SetScript("OnEnter", function()
        tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    end)

    grip:SetScript("OnLeave", function()
        tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    end)

    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SaveWindowState(stateKey, self)
    end)
end


-- ============================================================
-- Minimap button
-- ============================================================
-- Classic WoW 3.3.5a compatible minimap button.
-- Left-click opens RRH.
-- Right-click toggles Group Loot <-> Master Looter when the player
-- has the appropriate group/raid authority. Holding the right mouse
-- button and dragging moves the button around the minimap edge.
-- The angle is persisted in RaidRollHelperDB.
local RRHMinimapButton = nil

local function RRHMinimapCanChangeLootMethod()
    if not GetLootMethod or not SetLootMethod then
        return false
    end

    local inRaid = GetNumRaidMembers and GetNumRaidMembers() > 0
    local inParty = GetNumPartyMembers and GetNumPartyMembers() > 0
    if not inRaid and not inParty then
        return false
    end

    -- WoW 3.3.5a uses the pre-Cataclysm leader/officer APIs.
    if inRaid and IsRaidLeader and IsRaidLeader() then
        return true
    end

    if inParty and not inRaid and IsPartyLeader and IsPartyLeader() then
        return true
    end

    -- Raid assistants/officers are supported by the 3.3.5a API.
    if inRaid and IsRaidOfficer and IsRaidOfficer() then
        return true
    end

    return false
end

local function RRHMinimapToggleLootMethod()
    if not RRHMinimapCanChangeLootMethod() then
        if Info then
            Info("You need raid/party leader (or raid assistant) rights to change the loot method.")
        end
        return
    end

    local method = select(1, GetLootMethod())
    local playerName = UnitName("player") or ""

    if method == "group" then
        -- Make the player the Master Looter.
        SetLootMethod("master", playerName)
        if Info then
            Info("Loot method: Master Looter")
        end
    elseif method == "master" then
        SetLootMethod("group")
        if Info then
            Info("Loot method: Group Loot")
        end
    else
        -- For any other current method, the first right-click switches
        -- directly to Master Looter. A second right-click switches back
        -- to Group Loot.
        SetLootMethod("master", playerName)
        if Info then
            Info("Loot method: Master Looter")
        end
    end
end

local function RRHMinimapUpdatePosition()
    if not RRHMinimapButton or not Minimap then
        return
    end

    EnsureDB()

    local angle = math.rad(tonumber(DB.minimapButton.angle) or 45)
    local radius = (Minimap:GetWidth() / 2) + 6

    RRHMinimapButton:ClearAllPoints()
    RRHMinimapButton:SetPoint(
        "CENTER",
        Minimap,
        "CENTER",
        math.cos(angle) * radius,
        math.sin(angle) * radius
    )
end

local function RRHMinimapSetAngleFromCursor()
    if not RRHMinimapButton or not Minimap then
        return
    end

    local x, y = GetCursorPosition()
    local scale = (Minimap.GetEffectiveScale and Minimap:GetEffectiveScale()) or UIParent:GetEffectiveScale()
    x = x / scale
    y = y / scale

    local mx, my = Minimap:GetCenter()
    if not mx or not my then
        return
    end

    local angle = math.atan2(y - my, x - mx)
    DB.minimapButton.angle = math.deg(angle)
    RRHMinimapUpdatePosition()
end

function CreateRRHMinimapButton()
    if RRHMinimapButton then
        RRHMinimapUpdatePosition()
        return RRHMinimapButton
    end

    EnsureDB()

    local b = CreateFrame("Button", "RRHMinimapButton", Minimap)
    RRHMinimapButton = b

    b:SetWidth(28)
    b:SetHeight(28)
    b:SetFrameStrata("HIGH")
    b:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 20)
    b:SetToplevel(true)
    b:EnableMouse(true)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("RightButton")

    local iconPath = "Interface\\AddOns\\RaidRollHelper_RisingGodsEdition\\Textures\\RRH_Minimap.blp"
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints(b)
    icon:SetTexture(iconPath)
    icon:SetTexCoord(0, 1, 0, 1)
    icon:SetVertexColor(1, 1, 1, 1)
    icon:SetAlpha(1)
    b.icon = icon

    local highlight = b:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetAllPoints(b)
    highlight:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    highlight:SetAllPoints(b)
    highlight:SetBlendMode("ADD")
    highlight:SetAlpha(0.35)

    b:SetScript("OnClick", function(self, mouseButton)
        if mouseButton == "LeftButton" then
            -- Same behavior as /rrh.
            if RRH_UI and RRH_UI.Toggle then
                RRH_UI:Toggle()
            else
                ToggleFrameCompat(frame)
            end
        elseif mouseButton == "RightButton" and not self.dragging then
            -- A normal right-click changes the loot method. If the
            -- button is dragged, OnDragStart/OnDragStop handles it
            -- instead and this branch is intentionally skipped.
            RRHMinimapToggleLootMethod()
        end
    end)

    b:SetScript("OnDragStart", function(self)
        self.dragging = true
    end)

    b:SetScript("OnDragStop", function(self)
        self.dragging = false
        RRHMinimapSetAngleFromCursor()
    end)

    b:SetScript("OnUpdate", function(self)
        if self.dragging then
            RRHMinimapSetAngleFromCursor()
        end
    end)

    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Raid Roll Helper")
        GameTooltip:AddLine("Left-click: Open", 1, 1, 1)
        GameTooltip:AddLine("Right-click: Group Loot / Master Looter", 1, 1, 1)
        GameTooltip:AddLine("Right-drag: Move", 1, 1, 1)
        GameTooltip:Show()
    end)

    b:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    RRHMinimapUpdatePosition()
    b:Show()

    return b
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("CHAT_MSG_SYSTEM")
eventFrame:RegisterEvent("ADDON_LOADED")
-- ============================================================
-- Optional automatic Master-Loot assignment (preview feature)
-- ============================================================

local RRH_AUTOLOOT_SAROS_ID = 49908       -- Primordial Saronite
local RRH_AUTOLOOT_SHARD_ID = 50274       -- Shadowfrost Shard

local rrhPendingAutoLoot = nil

local function RRHAutoLootItemID(link)
    if not link then return nil end
    return tonumber(link:match("item:(%d+)"))
end

local function RRHAutoLootNameMatches(candidate, wanted)
    wanted = NormalizeSpaces(wanted or "")
    candidate = NormalizeSpaces(candidate or "")
    if wanted == "" or candidate == "" then return false end

    local c = candidate:lower()
    local w = wanted:lower()
    if c == w then return true end

    -- Rising Gods/3.3.5 can expose a realm suffix in candidate names.
    local base = c:match("^([^%-]+)") or c
    return base == w
end

local function RRHFindMasterLootCandidate(wanted)
    if not wanted or wanted == "" or not GetMasterLootCandidate then
        return nil
    end
    local i
    for i = 1, 40 do
        local candidate = GetMasterLootCandidate(i)
        if candidate and RRHAutoLootNameMatches(candidate, wanted) then
            return i, candidate
        end
    end
    return nil
end

local function RRHAutoLootCategory(link, quality)
    local itemID = RRHAutoLootItemID(link)
    if not itemID then return nil end

    if itemID == RRH_AUTOLOOT_SAROS_ID then
        return "saros"
    end
    if itemID == RRH_AUTOLOOT_SHARD_ID then
        return "shards"
    end

    -- Boss-loot target means actual epic/legendary boss items. Do not
    -- automatically redirect emblems, currency or arbitrary low-quality loot.
    if tonumber(quality) and tonumber(quality) >= 4 then
        return "boss"
    end
    return nil
end

local function RRHBuildAutoLootPreview()
    local session = GetCurrentSession()
    local autoLoot = GetSessionAutoLootConfig(session)
    if not session or not autoLoot or not autoLoot.enabled then
        return nil
    end

    local method = GetLootMethod and select(1, GetLootMethod())
    if method ~= "master" then
        return nil
    end

    local playerName = NormalizePlayerName(UnitName("player") or "")
    local masterName = ""
    local _, _, masterRaidID = GetLootMethod()
    if masterRaidID and GetRaidRosterInfo then
        masterName = NormalizePlayerName(GetRaidRosterInfo(masterRaidID) or "")
    end
    if masterName ~= "" and masterName ~= playerName then
        return nil
    end

    local result = {}
    local slot
    for slot = 1, GetNumLootItems() do
        local _, _, _, quality = GetLootSlotInfo(slot)
        local link = GetLootSlotLink(slot)
        local category = RRHAutoLootCategory(link, quality)
        if category then
            local wanted = autoLoot[category] or ""
            if wanted ~= "" then
                local candidateIndex, candidateName = RRHFindMasterLootCandidate(wanted)
                if candidateIndex then
                    table.insert(result, {
                        slot = slot,
                        link = link,
                        category = category,
                        target = candidateName,
                        candidateIndex = candidateIndex
                    })
                else
                    table.insert(result, {
                        slot = slot,
                        link = link,
                        category = category,
                        target = wanted,
                        missing = true
                    })
                end
            end
        end
    end

    if table.getn(result) == 0 then
        return nil
    end
    return result
end

local function RRHAutoLootPreviewText(items)
    local lines = {"RRH automatische Loot-Zuweisung", ""}
    local labels = {boss="Boss-Loot", saros="Saros", shards="Splitter"}
    local i, item
    for i, item in ipairs(items) do
        local name = item.link or ("Loot-Slot "..tostring(item.slot))
        if item.missing then
            table.insert(lines, "NICHT ZUGEWIESEN: "..labels[item.category]..": "..name.." -> "..tostring(item.target).." (Spieler nicht gefunden)")
        else
            table.insert(lines, labels[item.category]..": "..name.." -> "..tostring(item.target))
        end
    end
    table.insert(lines, "")
    table.insert(lines, "Nur gefundene Spieler werden nach Bestätigung automatisch verteilt.")
    return table.concat(lines, "\n")
end

StaticPopupDialogs["RRH_AUTOLOOT_CONFIRM"] = {
    text = "%s",
    button1 = "Zuweisen",
    button2 = "Abbrechen",
    OnAccept = function()
        local items = rrhPendingAutoLoot
        rrhPendingAutoLoot = nil
        if not items then return end

        local function GiveNext(index)
            local item = items[index]
            if not item then return end

            if not item.missing and GiveMasterLoot then
                local currentSlot = nil
                local slot
                for slot = 1, GetNumLootItems() do
                    local currentLink = GetLootSlotLink(slot)
                    if currentLink and currentLink == item.link then
                        currentSlot = slot
                        break
                    end
                end

                local idx = RRHFindMasterLootCandidate(item.target)
                if currentSlot and idx then
                    GiveMasterLoot(currentSlot, idx)
                elseif Info then
                    Info("RRH: Zielspieler oder Loot-Slot für "..tostring(item.target).." wurde nicht gefunden. Loot bleibt offen.")
                end
            end

            -- GiveMasterLoot changes/reindexes the loot window asynchronously.
            -- Wait before handling the next item so two identical links are
            -- processed as two separate loot slots.
            if After then
                After(0.35, function() GiveNext(index + 1) end)
            else
                GiveNext(index + 1)
            end
        end
        GiveNext(1)
    end,
    OnCancel = function()
        rrhPendingAutoLoot = nil
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3
}

function RRHProcessAutomaticLootAssignment()
    local items = RRHBuildAutoLootPreview()
    if not items then
        return
    end

    local session = GetCurrentSession()
    local autoLoot = session and GetSessionAutoLootConfig(session) or nil
    if autoLoot and autoLoot.confirm ~= false then
        rrhPendingAutoLoot = items
        StaticPopup_Show("RRH_AUTOLOOT_CONFIRM", RRHAutoLootPreviewText(items))
        return
    end

    rrhPendingAutoLoot = items
    local function GiveNext(index)
        local item = items[index]
        if not item then
            rrhPendingAutoLoot = nil
            return
        end

        if not item.missing then
            local currentSlot = nil
            local slot
            for slot = 1, GetNumLootItems() do
                if GetLootSlotLink(slot) == item.link then
                    currentSlot = slot
                    break
                end
            end
            local idx = RRHFindMasterLootCandidate(item.target)
            if currentSlot and idx then
                GiveMasterLoot(currentSlot, idx)
            end
        end

        if After then
            After(0.35, function() GiveNext(index + 1) end)
        else
            GiveNext(index + 1)
        end
    end
    GiveNext(1)
end

eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("RAID_ROSTER_UPDATE")
eventFrame:RegisterEvent("CHAT_MSG_LOOT")
eventFrame:RegisterEvent("LOOT_OPENED")
eventFrame:RegisterEvent("LOOT_CLOSED")
eventFrame:RegisterEvent("BAG_UPDATE")
eventFrame:RegisterEvent("TRADE_CLOSED")
eventFrame:RegisterEvent("PLAYER_LOGOUT")

eventFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "PLAYER_LOGOUT" then
        -- The SafeGuard addon receives the same event and snapshots the
        -- complete DB into its separate SavedVariables file.
        EnsureDB()
        RRHMarkCleanShutdown()
        return
    end

    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON_NAME then
            return
        end

        EnsureDB()
        RRHMarkSessionDirty()
        BuildBagCache()
        CreateRRHMinimapButton()

        if frame then RestoreWindowState("main", frame, 610, 450) end
        if logFrame then RestoreWindowState("log", logFrame, 470, 360) end
        if copyFrame then RestoreWindowState("copy", copyFrame, 520, 380) end
        if newRaidFrame then RestoreWindowState("newraid", newRaidFrame, 380, 190) end
        if lootFrame then RestoreWindowState("loot", lootFrame, 420, 420) end

        if frame then MakeFrameResizable(frame, "main", 520, 360) end
        if logFrame then MakeFrameResizable(logFrame, "log", 360, 240) end
        if copyFrame then MakeFrameResizable(copyFrame, "copy", 400, 240) end
        if newRaidFrame then MakeFrameResizable(newRaidFrame, "newraid", 320, 160) end
        if lootFrame then MakeFrameResizable(lootFrame, "loot", 320, 340) end

        if sc then sc:SetChecked(soundEnabled) end
        if lc then lc:SetChecked(logEnabled) end

        CleanupExpiredLoot()
        ResetActiveInfo()
        return
    end

    if event == "PLAYER_ENTERING_WORLD" or event == "RAID_ROSTER_UPDATE" then
        if DB then
            RefreshSessionStateFromWorld(event)
        end
        return
    end

    if event == "BAG_UPDATE" then
        ScheduleLootRescans()
        return
    end

    if event == "LOOT_CLOSED" then
        local captureToken = RRH_CurrentLootWindowCaptureToken
        RRH_CurrentLootWindowCaptureToken = nil

        if captureToken and After then
            After(2.0, function()
                if RemoveUnboundLootWindowEntries then
                    RemoveUnboundLootWindowEntries(captureToken)
                end
                if RRH_UI and RRH_UI.Refresh then
                    RRH_UI:Refresh()
                end
            end)
        end
        return
    end

    if event == "TRADE_CLOSED" then
        CheckPendingTradeRemoval(true)
        return
    end

    if event == "LOOT_OPENED" then
        -- LOOT_OPENED can fire more than once while the same loot window is
        -- active. Keep one capture token until LOOT_CLOSED so the same slot
        -- is not imported again under a fresh token.
        if not RRH_CurrentLootWindowCaptureToken then
            RRH_CurrentLootWindowCaptureToken = tostring(time()) .. ":" .. tostring(math.random(100000, 999999))
        end
        AnnounceMasterLootEpicItems()

        if InRaidGroup() and GetLootMethod and GetNumLootItems and GetLootSlotInfo and GetLootSlotLink then
            local lootMethod, masterlooterPartyID, masterlooterRaidID = GetLootMethod()
            local shouldCapture = false
            local lootSource = nil

            if lootMethod == "master" then
                -- Only the actual Master Looter should import the open loot window.
                local playerName = NormalizePlayerName(UnitName("player") or "")
                local masterName = ""
                if masterlooterRaidID and GetRaidRosterInfo then
                    masterName = NormalizePlayerName(GetRaidRosterInfo(masterlooterRaidID) or "")
                end
                if masterName == "" or masterName == playerName then
                    shouldCapture = true
                    lootSource = "MASTER_LOOT"
                end
            elseif lootMethod == "group" then
                -- Group Loot was previously missed entirely because the old
                -- handler only processed the "master" branch. Capture the
                -- same eligible raid loot from the loot window here as well.
                -- The later BAG_UPDATE scan will bind the entry to the bag
                -- when the player actually wins/receives the item.
                shouldCapture = true
                lootSource = "GROUP_LOOT"
            end

            if shouldCapture then
                local bossName = NormalizeSpaces(UnitName("target") or "Boss")
                local slot
                for slot = 1, GetNumLootItems() do
                    local _, _, _, quality = GetLootSlotInfo(slot)
                    if quality == 4 or quality == 5 then
                        local link = GetLootSlotLink(slot)
                        if link and link ~= "" then
                            AddLootQueueItemFromLootWindow(link, bossName, lootSource, slot)
                        end
                    end
                end
                -- Preview/automatic assignment runs only for Master Loot and only
                -- for the configured categories.
                if lootMethod == "master" then
                    RRHProcessAutomaticLootAssignment()
                end
                if RRH_UI and RRH_UI.Refresh then
                    RRH_UI:Refresh()
                end
            end
        end
        return
    end

    if event == "CHAT_MSG_LOOT" then
        if not DB then
            EnsureDB()
        end

        local msg = tostring(arg1 or "")
        local itemLink = msg:match("(|c%x%x%x%x%x%x%x%x|Hitem:[^|]+|h%[[^%]]+%]|h|r)")
        if itemLink and IsEpicOrLegendaryByLink(itemLink) then
            ScheduleLootRescans()
        end
        return
    end

    if not activeRoll then
        return
    end
    if activeRoll.waitingStart then
        return
    end

    local msg = tostring(arg1 or "")
    local p, r, minRoll, maxRoll = msg:match("^(.-)%s+(%d+)%s+%((%d+)%-(%d+)%)$")
    if not p then
        return
    end

    p = NormalizePlayerName(p)
    r = tonumber(r)
    minRoll = tonumber(minRoll)
    maxRoll = tonumber(maxRoll)
    if not r or not minRoll or not maxRoll then
        return
    end

    local validType = nil
    if minRoll == 101 and maxRoll == 200 then
        validType = "FOCUS"
    elseif minRoll == 1 and maxRoll == 100 then
        validType = "MS"
    elseif minRoll == 1 and maxRoll == 99 then
        validType = "OS"
    else
        return
    end

    if activeRoll.eligiblePlayers and not activeRoll.eligiblePlayers[p] then
        return
    end

    if activeRoll.eligiblePlayers and activeRoll.rerollType and validType ~= activeRoll.rerollType then
        return
    end

    -- Some clients/server-side roll systems can resend the same roll event
    -- repeatedly. Never announce the same rejection over and over during one
    -- active roll; keep the notice state on the roll itself so it resets
    -- naturally when the roll ends.
    activeRoll.ignoredRollNotices = activeRoll.ignoredRollNotices or {}
    local function NoticeIgnoredRollOnce(reason)
        local key = tostring(p) .. "|" .. tostring(reason)
        if activeRoll.ignoredRollNotices[key] then
            return
        end
        activeRoll.ignoredRollNotices[key] = true
        RaidSay(p .. " + " .. tostring(reason))
    end

    if validType == "FOCUS" then
        activeRoll.focus[p] = activeRoll.focus[p] or {}
        if #activeRoll.focus[p] >= 2 then
            NoticeIgnoredRollOnce("Focus Roll ignored (maximum two Focus Rolls)")
            return
        end

        if not activeRoll.tokenMode and activeRoll.players[p] then
            NoticeIgnoredRollOnce("Focus Roll ignored (another roll type already recorded)")
            return
        end

        table.insert(activeRoll.focus[p], r)
    else
        if activeRoll.tokenMode then
            activeRoll.normalRollType = activeRoll.normalRollType or {}
            if activeRoll.normalRollType[p] then
                NoticeIgnoredRollOnce(validType .. " ignored (normal roll already recorded)")
                return
            end

            activeRoll.normalRollType[p] = validType
            activeRoll.players[p] = true
            if validType == "MS" then
                activeRoll.ms[p] = r
            else
                activeRoll.os[p] = r
            end
        else
            if activeRoll.players[p] or (activeRoll.focus[p] and #activeRoll.focus[p] > 0) then
                NoticeIgnoredRollOnce("Multiroll ignored")
                return
            end
            activeRoll.players[p] = true
            if validType == "MS" then
                activeRoll.ms[p] = r
            else
                activeRoll.os[p] = r
            end
        end
    end
    AddRollHistory(p, validType, r, activeRoll.reroll and "reroll" or "main")
end)

local lootRefreshElapsed = 0
timerFrame:SetScript("OnUpdate", function(_, elapsed)
    local i
    for i = #timers, 1, -1 do
        local t = timers[i]
        t.time = t.time - elapsed
        if t.time <= 0 then
            t.func()
            table.remove(timers, i)
        end
    end

    if activeRoll then
        activeRoll.timeLeft = (activeRoll.timeLeft or 0) - elapsed
        if activeRoll.timeLeft < 0 then
            activeRoll.timeLeft = 0
        end
        UpdateActiveInfoText()
    else
        ResetActiveInfo()
    end

    lootRefreshElapsed = lootRefreshElapsed + elapsed
    if lootRefreshElapsed >= 0.2 then
        lootRefreshElapsed = 0
        if lootFrame and lootFrame:IsShown() then
            RenderLootWindow()
        end
    end
end)

SLASH_RRH1 = "/rrh"
SLASH_RRH2 = "/raidrollhelper"
SlashCmdList["RRH"] = function()
    ToggleFrameCompat(frame)
end

SLASH_RR11 = "/rr1"
SlashCmdList["RR1"] = function(msg)
    local item, duration = ParseRollInput(msg, DEFAULT_ROLL_TIME)
    StartRoll(item, duration)
end

SLASH_RRLOG1 = "/rrlog"
SlashCmdList["RRLOG"] = function()
    ToggleFrameCompat(logFrame)
    if logFrame and logFrame:IsShown() then
        RenderLogView()
    end
end

SLASH_RRLOOT1 = "/rrloot"
SlashCmdList["RRLOOT"] = function()
    ToggleFrameCompat(lootFrame)
    if lootFrame and lootFrame:IsShown() then
        RenderLootWindow()
    end
end

SLASH_RRCANCEL1 = "/rrcancel"
SlashCmdList["RRCANCEL"] = function()
    CancelRoll()
end

SLASH_RRNEW1 = "/rrnew"
SlashCmdList["RRNEW"] = function()
    ToggleFrameCompat(newRaidFrame)
end

SLASH_RRTEST1 = "/rrtest"
SlashCmdList["RRTEST"] = function(msg)
    msg = Trim(msg or "")

    local itemLink = msg:match("(|c%x%x%x%x%x%x%x%x|Hitem:[^|]+|h%[[^%]]+%]|h|r)")
    local bag, slot
    if itemLink then
        bag, slot = FindUntrackedBagSlotByLink(itemLink)
        if not bag or not slot then
            bag, slot = FindBagSlotByExactLink(itemLink)
        end
    else
        itemLink, bag, slot = FindFirstEpicLegendaryBagItem()
    end

    if not itemLink then
        Info("No item linked or found in bags")
        return
    end

    if not DB then
        EnsureDB()
    end

    local entry = AddLootQueueItem(itemLink, bag, slot)
    if not entry then
        Info("RRTEST failed to add item")
        return
    end

    if lootFrame then
        lootFrame:Show()
    end

    RefreshLootBagSlot(entry)
    RenderLootWindow()
    Info("Test item added: " .. tostring(itemLink))
end
